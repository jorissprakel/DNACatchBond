from __future__ import division
import base
import readers
import types
import os
import sys
import numpy as np
import math

##########################################################################

#NOTE: This script takes a simulation trajectory (mstrajectory.dat), and computes the connection order parameters of the latch sequence, toehold, cross-link and barrier sequence.
#these results are stored as states.csv. The results can then be read by plot_state_overtime_activation.py and plot_states_overtime_assembly.py to plot the order parameter graphs
#in figure S2a and S2b.
#NOTE: This script should be run with python2.

#########################################################################

storagefilename = 'states.csv'

#Specify the path to the simulation trajectory you wish to analyze

#### e.g. for one of the catch bond activation simulations:
#folderpath = '../../../data/23-04-24_activation_CB/'
#measurementpath = folderpath+'simulation/30/7/measurement/'

#### e.g. for one of the catch bond deactivation simulations:
folderpath = '../../../data/sim_deactivate_0pN/'
measurementpath = folderpath+'simulation/0.0/2/measurement/'

#Sets the cutoff two corresponding basepairs must be near to one another in order for them to be considered connected
global cutoffdistance
cutoffdistance = 0.5	#0.5 = 0.4259 nm according to the model
nr_frames = 2000 		#nr of frames stored in the trajectory
Deltat = 50000			#time difference per frame

#Set Control Sequences for evaluating which of the domains. These are the left most and right most  
#base pairs corresponding to the weak link, barrier, latch, toehold etc. (in this case for CB9b7):
weak_link1 = (0,8)
barrier1 = (10,15)
latch1 = (16,22)
toe1 = (23,28)
toe2 = (33,38)
latch2 = (39,45)
barrier2 = (46,51)
latch2 = (56,62)
weak_link2 = (70,78)

#Define which pairs of BP should be compared to determine order parameters
weak_pairs =[]
c=0
for i in range(weak_link1[0],weak_link1[1]+1):
	weak_pairs.append([weak_link1[0]+c,weak_link2[1]-c])
	c+=1

barrier_pairs=[]
c=0
for i in range(barrier1[0],barrier1[1]+1,1):
	barrier_pairs.append([barrier1[0]+c,barrier2[1]-c])
	c+=1

latch_pairs = []
c=0
for i in range(latch1[0],latch1[1]+1):
	latch_pairs.append([latch1[0]+c,latch2[1]-c])
	c+=1

toe_pairs = []
c=0
for i in range(toe1[0],toe1[1]+1):
	toe_pairs.append([toe1[0]+c,toe2[1]-c])
	c+=1

##Function that determines the order parameters of each of the pairs of BP (latch, barrier, cross-link and toehold)
def determineorderparameter(positions,pairs,boxsize):
	#This script takes a list of pairs(e.g. [[0,10],[1,9],[2,8]...etc.])
	#And returns the fraction of bonds within the pair that is within binding proximity to one another.
	nr_matchesfound=0
	for i,pair in enumerate(pairs):

		firstpos = positions[pair[0],:]
		secondpos = positions[pair[1],:]

		dx = abs(secondpos[0]-firstpos[0])
		dy = abs(secondpos[1]-firstpos[1])
		dz = abs(secondpos[2]-firstpos[2])

		#correct for periodic boundary conditions
		while dx>boxsize[0]:
			dx-=boxsize[0]
		while dy>boxsize[1]:
			dy-=boxsize[1]
		while dz>boxsize[2]:
			dz-=boxsize[2]

		r=math.sqrt(dx**2+dy**2+dz**2)
		
		if r<float(cutoffdistance):
			nr_matchesfound+=1

	return(nr_matchesfound/(i+1))

#Find the oxDNA input file and trajectory file.
inputfile=measurementpath+"input.txt"
trajfile=measurementpath+"mstrajectory.dat"
trajfile=os.path.abspath(trajfile)

#Read out the oxDNA topologyfile from the input file
topologyfile = ""
fin = open(inputfile)
for line in fin:
    line = line.lstrip()
    if not line.startswith('#'):
        if "topology" in line:
            topologyfile = line.split('=')[1].replace(' ','').replace('\n','')

#Navigate to the input file.
inputfilesplitted = inputfile.split("/")
inputpath=""
for i,elem in enumerate(inputfilesplitted[:-1]):
	inputpath+=elem
	inputpath+="/"
currentpath=os.getcwd()
os.chdir(inputpath)

topologyfile=os.path.abspath(topologyfile)

frames = np.array(range(nr_frames))
times = np.multiply(frames,Deltat)
weak_ops = np.zeros(nr_frames)
barrier_ops = np.zeros(nr_frames)
latch_ops = np.zeros(nr_frames)
toe_ops = np.zeros(nr_frames)

#Start reading out the trajectory information using the oxDNA reader (LorenzoReader from the reader files.)
os.chdir(currentpath+"/")
myreader = readers.LorenzoReader(trajfile,topologyfile)
#loop over the frames and determine the order parameters in each frame
for frame in range(nr_frames):

	if frame % 40 ==0:		#Store every 40 frames.
		print("Analysis at "+str((frame/nr_frames)*100)+str(" %"))

	mysystem = myreader.get_system()
	nr_strands = mysystem.get_N_strands()
	nr_nucleotides = mysystem.get_N_Nucleotides()
	boxsize=mysystem._box
	time=mysystem._time

	basepositions=np.zeros((nr_nucleotides,4))
	counter=0
	for i,strand in enumerate(mysystem._strands):
		for j, nucleotide in enumerate(mysystem._strands[i]._nucleotides):
			basepositions[counter,0:3]=nucleotide.get_pos_base()
			basepositions[counter,3]=i
			counter+=1

	#determine the order parameters of each of the control sequences in each frame.
	weak_ops[frame]=determineorderparameter(basepositions,weak_pairs,boxsize)
	barrier_ops[frame]=determineorderparameter(basepositions,barrier_pairs,boxsize)
	latch_ops[frame]=determineorderparameter(basepositions,latch_pairs,boxsize)
	toe_ops[frame]=determineorderparameter(basepositions,toe_pairs,boxsize)

#Store the order parameters as states.csv.
storagematrix=np.vstack((frames,times,weak_ops,barrier_ops,latch_ops,toe_ops)).T
np.savetxt(measurementpath+'states.csv',storagematrix,delimiter=",",header = "frames,times,weak,barrier,latch,toe")
print("--- Analysis Finished ---")
