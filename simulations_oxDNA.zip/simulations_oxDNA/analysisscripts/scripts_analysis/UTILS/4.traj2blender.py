#!/usr/bin/env python

#This script is part of the oxDNA package. Please cite their work if you use it:
#https://dna.physics.ox.ac.uk/index.php/License_and_Copyright

#This script reads the oxDNA trajectory files and outputs and outputs a mstrajectory.csv file
#This csv file can in turn be loaded by the blender_video.py script to translate it into a blender scene for animation.
#Note: has to be run with python2

#run this script from the command line as:  "python2 traj2blender.py trajectorypath topologypath", such as:
#e.g.: python2 traj2blender.py ../../../data/sim_activate_30pN/simulation/30/7/measurement/mstrajectory.dat ../../../data/sim_activate_30pN/initiation/initialtopology.top


import base
import readers
try:
    import numpy as np
except:
    import mynumpy as np
import os.path
import sys
import fileinput
import getopt

input_options = ['seq_base_colour','colour_by_domain=']

longArgs=input_options
shortArgs='sc:'

try:
    args, files = getopt.getopt(sys.argv[1:], shortArgs, longArgs)
except:
    base.Logger.log( "Wrong usage. Aborting",base.Logger.CRITICAL)
    sys.exit (-2)


if len(files) < 2:
    base.Logger.log("Usage is %s configuration topology [output]" % sys.argv[0], base.Logger.CRITICAL)
    sys.exit()

if len(files) >2:
    output = files[2]
else: output = files[0] + ".csv"

l = readers.LorenzoReader(files[0], files[1])
s = l.get_system()

cdm20 = True
append = False

colour_by_seq=True

while s:

    if cdm20:

        cdm = np.array ([0.,0.,0.])
        for strand in s._strands:
            for n in strand._nucleotides:
                cdm += n.cm_pos
        cdm = cdm / float (s.get_N_Nucleotides())
        for strand in s._strands:
            strand.translate (-cdm)

    s.print_pdb_output_Blender(output, append=append,colour_by_seq=colour_by_seq)
    s = l.get_system()
    append = True

base.Logger.log("Output printed on '%s'" % output, base.Logger.INFO)
