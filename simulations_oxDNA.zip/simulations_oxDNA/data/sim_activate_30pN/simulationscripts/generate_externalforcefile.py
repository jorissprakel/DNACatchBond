
#This script is called by generate_measurearchitecture.py. It generates the external force file which can be read by oxDNA to apply the external force.

def generate_externalforce(parameterlib,outputfilename):

	# 1 reduced unit of force = 4.863*10^-11 N = 48.63 pN
	# The input is given in pN, so the force in reduced units is input/48.63
	# Because the force is applied on two ends of the bond in opposite directions,
	# the force is further divided by two to obtain the magnitude applied to each end.

	unitcorrection = 48.63 
	Forcemagnitude=(1/2)*parameterlib['force']/unitcorrection

	forcefiletext="{\ntype = string\nparticle = "+str(parameterlib["p1"])+"\nF0 = "+str(Forcemagnitude)\
	+"\nrate = 0\ndir = -1., 0., 0.\n}\n\n"\
	+"{\ntype = string\n particle = "+str(parameterlib["p2"])+"\nF0 = "+str(Forcemagnitude)\
	+"\nrate = 0\ndir = 1., 0., 0.\n}"

	outputfile = open(outputfilename,'w')
	outputfile.write(forcefiletext)
	outputfile.close()
	#print("--- oxDNA external force file written to: "+outputfilename+" ---")


