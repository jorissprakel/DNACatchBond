
#This script is run by generate_measurearchitecture.py
#it generates a list of simulations which are looped over by running the SLURM scheduler on "initiate_jobarrayparallel.sh" to start a series of simulations.

def generate_simulationslist(forces,nr_simulations):

	simulationslst = range(0,nr_simulations)

	lstfile = open('simulationslist.txt','w')
	for elem in forces:
		for nr in simulationslst:
			lstfile.write(str(elem)+' '+str(nr)+'\n')
			
	lstfile.close()
