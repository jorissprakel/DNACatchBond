#!/bin/bash
#SBATCH --array=0-31
#SBATCH --ntasks=1
#SBATCH --time=240:00:00
#SBATCH --mem-per-cpu=5000
#SBATCH --error=error_output_%j.txt
#SBATCH --qos=std
#SBATCH --mail-type=NONE
#SBATCH --mail-user=martijn.vangalen@wur.nl

export PATH=~/modules/oxdna/build/bin/:$PATH

inputfile="simulationslist.txt"

declare counter
counter=0
cat $1 | while read force repeatnr
do

if [ $counter == $SLURM_ARRAY_TASK_ID ]; then

	currentdir=`pwd`
	cd ../simulation/$force/$repeatnr/
	cd equilibrate/
	
	srun oxDNA input.txt
	cd ../measurement/
	
	srun oxDNA input.txt
	cd $currentdir
fi

counter=$(expr $counter + 1)

done <"$inputfile"
