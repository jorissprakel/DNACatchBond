import random

#This script is called by generate_measurearchitecture.py. 
#It generates the oxDNA input file which can be read by oxDNA to start a simulation.

def generate_input(parameterlib,outputfilename):

	outputfile = open(outputfilename,'w')
	for elem in parameterlib:
		outputfile.write(elem+" = "+str(parameterlib[elem])+"\n")

	outputfile.close()
	#print("--- oxDNA input file written to: "+outputfilename+" ---")


