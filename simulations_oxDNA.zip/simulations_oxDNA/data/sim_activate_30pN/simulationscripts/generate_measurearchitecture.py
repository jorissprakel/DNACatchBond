import numpy as np
import os
from generate_oxDNAinput import *
from generate_externalforcefile import *
from generate_simulationslist import *
import random
import numpy


#########################################################################################################################################

#### NOTE: This script generates the simulation architecture. 
#### On top, we set simulation parameters such as the simulation time, number or frepeats, applied tension force etc.
#### The output is a folder called "simulation" which contains a subfolder for each of the simulation repeats. 
#### each of these subfolders contains then an equilibrate folder and a measurement folder, which contain the input files necessary to run the oxDNA simulations
#### After running this script, a simulation can be started individually by running the input files with oxDNA from the command line: "oxDNA input.txt"
#### For the manuscript, we performed the list of simulations in bulk, using the SLURM scheduler and the initiate_jobarrayparallel.sh file

####For more information on the oxDNA model, please visit their website https://dna.physics.ox.ac.uk/index.php/DNA_model_introduction

########MAIN PARAMETERS OF THE SIMULATION SERIES##############

#Database for storing the parameters
database = {}

#total tensional string force in pN applied to the bond
database.update({"Forces":np.array([30])}) 						
unitvector = np.ones(len(database["Forces"]))

#Number of repeated simulations per force
nr_simulations = 30 											
nr_repeats = unitvector*nr_simulations
nr_repeats = nr_repeats.astype("int")

#Number of equilibration steps before the main simulation starts
equilibrationsteps = 10000

#Simulation temperature, reduced unit 1 = 3000 K
equilibrationtemperature = 0.0977167 # 0.0977167 = 20 C

#Number of MD steps during the main simulation
database.update({"steps":unitvector*1600000000})
#Set step size during the main simulation
database.update({"dt":unitvector*0.005})
#temperature during the main simulation
database.update({"T":unitvector*0.0977167})
#Salt concentratio nduring the main simulation = 0.1 M
database.update({"salt_concentration":unitvector*0.100})
#Print the energy every x steps
database.update({"print_energy_every":unitvector*400000})
#Print the conformation every x steps.
database.update({"print_conf_interval":unitvector*400000})

#The following are the indices of the DNA bases that the
#left-facing and right-facing force components will be applied to.
#Please make sure these are set to the outermost bases of the red and blue strand (in the manuscript this is 55 and 82)
leftforceparticle = 55	
rightforceparticle = 82

##################################### ########################

#List of standard parameters that are not changed often.
#The parameters defined above are plugged into this list to give the overall input parameters.
parameters_standard = {
"backend":"CPU",
"backend_precision":"double",
"debug":1,
"seed":None,
"sim_type":"MD",
"interaction_type":"DNA2",
"newtonian_steps":103,
"thermostat":"john",
"verlet_skin":0.1,
"use_average_seq":1,
"diff_coeff":2.50,
"salt_concentration":None,
"T":None,
"steps":None,
"dt":None,
"time_scale":"linear",
"print_energy_every":50000,
"print_conf_interval":50000,
"topology":"",
"conf_file":"",
"lastconf_file":"",
"trajectory_file":"",
"log_file": "",
"energy_file":"",
"order_parameters_file":"op.txt",
"ffs_file":"ffs.txt",
"refresh_vel":1,
"print_conf_ppc":51,
"no_stdout_energy":0,
"restart_step_counter":1,
"external_forces":0,
"external_forces_file":""
}

print(nr_simulations)

#Generate a list of all simulations to be done, using the generate_simulationslist.py script
generate_simulationslist(forces=database["Forces"],nr_simulations=nr_simulations)

#Loop over all the applied forces and over the number of repeats to be run
for forcecount,force in enumerate(database["Forces"]):
	for repeatnr in range(nr_repeats[forcecount]):

		#Make a simulation folder for each force and repeat number, where the oxDNA input parameters are dumped.
		os.makedirs("../simulation/"+str(force)+"/"+str(repeatnr)+"/equilibrate/")	#First for the equilibration

		#Fill in the equilibration parameters into the standard parameters list.
		parameters_equilibrate = parameters_standard.copy()
		parameters_equilibrate.update({"seed":random.randint(0,10000000)})
		parameters_equilibrate.update({"external_forces":0})
		parameters_equilibrate.update({"external_forces_file":None})
		parameters_equilibrate.update({"steps":equilibrationsteps})
		parameters_equilibrate.update({"dt":database["dt"][forcecount]})
		parameters_equilibrate.update({"T":equilibrationtemperature})
		parameters_equilibrate.update({"salt_concentration":database["salt_concentration"][forcecount]})
		parameters_equilibrate.update({"print_energy_every":database["print_energy_every"][forcecount]})
		parameters_equilibrate.update({"print_conf_interval":database["print_conf_interval"][forcecount]})

		#Fill in the location of the toplogy and initial conformation file, among the locations of other files.
		parameters_equilibrate.update({"topology":"../../../../initiation/initialtopology.top"})
		parameters_equilibrate.update({"conf_file":"../../../../initiation/initialconformation.conf"})
		parameters_equilibrate.update({"lastconf_file":"equilibrated.conf"})
		parameters_equilibrate.update({"trajectory_file":"eqtrajectory.traj"})
		parameters_equilibrate.update({"log_file":"eqlog.dat"})
		parameters_equilibrate.update({"energy_file":"eqenergy.dat"})

		#Generate the oxDNA input file for the equilibration using the generate_input.py script.
		generate_input(parameterlib=parameters_equilibrate,outputfilename="../simulation/"+str(force)+"/"+str(repeatnr)+"/equilibrate/input.txt")

		#Repeat the same for the main simulation loop file. First we generate a simulation folder called measurement:
		os.makedirs("../simulation/"+str(force)+"/"+str(repeatnr)+"/measurement/")

		#Next we fill in the simulation parameters of the main simulation loop into the standard parameters list
		parameters_measure = parameters_standard.copy()
		parameters_measure.update({"seed":random.randint(0,10000000)})
		parameters_measure.update({"external_forces":1})
		parameters_measure.update({"external_forces_file":"externalforce.txt"})
		parameters_measure.update({"steps":database["steps"][forcecount]})
		parameters_measure.update({"dt":database["dt"][forcecount]})
		parameters_measure.update({"T":database["T"][forcecount]})
		parameters_measure.update({"salt_concentration":database["salt_concentration"][forcecount]})
		parameters_measure.update({"print_energy_every":database["print_energy_every"][forcecount]})
		parameters_measure.update({"print_conf_interval":database["print_conf_interval"][forcecount]})

		#Fill in the location of the toplogy and initial conformation file, among the locations of other files.
		#Please note that for the main simulation loop, the initial conformation is set to the output conformation of the equilibration loop.
		#Hence, the equilibration should be run first using oxDNA and then the main simulation should be run after, taking in the output of the equilibration.
		parameters_measure.update({"topology":"../../../../initiation/initialtopology.top"})
		parameters_measure.update({"conf_file":"../equilibrate/equilibrated.conf"})
		parameters_measure.update({"lastconf_file":"msconformation.conf"})
		parameters_measure.update({"trajectory_file":"mstrajectory.traj"})
		parameters_measure.update({"log_file":"mslog.dat"})
		parameters_measure.update({"energy_file":"msenergy.dat"})

		#Generate the oxDNA input file for the main simulation loop, using the generate_input.py script.
		generate_input(parameterlib=parameters_measure,outputfilename="../simulation/"+str(force)+"/"+str(repeatnr)+"/measurement/input.txt")

		#set the external force parameters
		externalforceparams = {
		"force":force,
		"p1":leftforceparticle,
		"p2":rightforceparticle
		}
		
		#Generate the external force file for oxDNA using the generate_externalforce.py function.
		generate_externalforce(parameterlib=externalforceparams,outputfilename="../simulation/"+str(force)+"/"+str(repeatnr)+"/measurement/externalforce.txt")

