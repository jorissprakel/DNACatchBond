import os
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import AutoMinorLocator,Locator
to_cm = 0.393701#inch to mm conversion


##################################################################################################################################################################################################
#NOTE: This script takes the stop times stored in by 2.rolling_analysis_separateregimes.py and plots the mean tstop as a function of gamma dot (fig. 2f of the manuscript)   #
#This script overlays the tstop plots of the slip bond control and of the catch bond (latch7)
#################################################################################################################################################################################################

######datasets used in the manuscript:
#datafolders = ['../TaieesaData/22-11-08-1.36um-50pRAT7/dataset/',
#                '../TaieesaData/22-11-16-1.36um-50pCB9_b7/dataset/',
#                ]


####Example dataset:
datafolders = ['../example_dataset_snippet/testdataset/dataset/']

colors=[
"#747575",
'#A31418'
]

labels=[
'slip_7',
'catch_9b7'
]

markers=[
"s",
"o"
]

#Set channel height and width (used to determine shearrate from flowrate)
channel_height = 50 #um
channel_width = 1500 #um

#Plot a figure
fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(7*to_cm, 7.5*to_cm)) #figsize=(3.6, 3.2) figsize=(5, 5)
plt.subplots_adjust(left=0.15, wspace=0.38, hspace=0.38, top=0.98, bottom=0.15, right=0.98)
ax.tick_params(axis='y',**{'which':'major','width':2.2,'length':6,'direction':'in','left':True,'right':True})
ax.tick_params(axis='y',**{'which':'minor','width':1.5,'length':3,'direction':'in','left':True,'right':True})  
ax.tick_params(axis='x',**{'which':'major','width':1.9,'length':6.5,'direction':'in','bottom':True,'top':True})    
ax.tick_params(axis='x',**{'which':'minor','width':1.3,'length':3.5,'direction':'in','bottom':True,'top':True})
[line.set_linewidth(1.6) for line in ax.spines.values()]

#loop over the datafolders
for folderindex,datafolder in enumerate(datafolders):

    datapoints = os.listdir(datafolder)

    datavalues = []
    for datapoint in datapoints:
        datavalues.append(float(datapoint[:-5]))

    if not os.path.exists(datafolder[:-8]+"results/stopping_analysis/survivalprobability/"):
        os.makedirs(datafolder[:-8]+"results/stopping_analysis/survivalprobability/")

    #Initialize array for storing the average tstop, standard deviation and shearrates.
    stoptimes_avg = []
    stoptimes_stdevs = []
    shearrates = []    

    #Loop over the measurements within the data folders.
    for dataindex, datapoint in enumerate(datapoints):

        stopping_information = np.loadtxt(datafolder+datapoint+'/traces/'+"stopping_information.csv",delimiter=',',skiprows=1)

        stoppingtimes = stopping_information[:,0]
        pindices = stopping_information[:,1]

        #Calculate the shear rate from the imposed flowrate.
        value = datapoint.split('ulmin')
        rate = value[0]
        value_int = float(rate)
        t = np.multiply(value_int, pow(10,8))
        b = np.multiply(pow(channel_height,2), channel_width)
        shear_rate = t / b
        shearrates.append(shear_rate)

        #Append the average stopping times and standard deviations to the stoptimes arrays.
        stoptimes_avg.append(np.average(stoppingtimes))
        stoptimes_stdevs.append(np.std(stoppingtimes))

    for tick in ax.xaxis.get_major_ticks():
        tick.label.set_fontsize(18)
    for tick in ax.yaxis.get_major_ticks():
        tick.label.set_fontsize(18)

    #Plot the stoptimes as a function of shear rate
    ax.scatter(shearrates,stoptimes_avg,c=colors[folderindex], marker=markers[folderindex],label = labels[folderindex])

    #Convert to numpy array
    stoptimes_avg = np.array(stoptimes_avg)
    stoptimes_stdevs = np.array(stoptimes_stdevs)

    #Plot the standard deviation as a filled area using the matplotlib fill_between function
    y_high = stoptimes_avg+stoptimes_stdevs
    y_low = stoptimes_avg-stoptimes_stdevs
    plt.fill_between(shearrates, y_low, y_high,color=colors[folderindex],edgecolor=None,alpha=0.3)

ax.xaxis.set_minor_locator(AutoMinorLocator(2))
ax.yaxis.set_minor_locator(AutoMinorLocator(2))

#ax.legend(frameon=False, loc = "upper right",fontsize= 14,handlelength=0.1)
ax.set_yscale("log")

plt.rcParams['font.size'] = '16'
#set x and y limits.
plt.xlim(xmin=0, xmax=1300)
ax.set_ylim(bottom = 0)

ax.set_ylabel(r"$t_{stop} \ \mathrm{[s]}$",fontsize=22)
ax.set_xlabel(r"$\dot{\gamma}\ [\mathrm{s}^{-1}]}$",fontsize=22)

#Store the figure as an svg
plt.savefig("t_stop_overlayed.svg")
print("\n -------- Figure saved as: t_stop_overlayed.svg ----------\n")
plt.show()
plt.close()
