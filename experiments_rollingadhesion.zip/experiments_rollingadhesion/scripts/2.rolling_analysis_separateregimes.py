import os
import numpy as np
import pandas as pd
import matplotlib as mpl

mpl.use('TkAgg')
import matplotlib.pyplot as plt
from scipy import signal

from scipy import stats
from scipy.optimize import curve_fit
from scipy import asarray as ar, exp

##################################################################################################################################################################################################################
#Note: This script takes the trajectories determined by 1.particletracking.py, separates the trajectories into rolling and stopping regimes, and stores the information of the rolling and stopping regimes as csv files.##
##################################################################################################################################################################################################################

##Dataset used in the manuscript:
#datafolders = [
#'../Data/22-11-08-1.36um-50pSB/dataset/', 
#'../Data/22-11-16-1.36um-50pCB9_L7/dataset/', 
#'../Data/22-12-08-1.36um-50pCB9_L2/dataset/', 
#'../Data/22-12-01-1.36um-50pCB9_L3/dataset/',
#'../Data/22-12-09-1.36um-50pCB9_L4/dataset/', 
#'../Data/22-12-14-1.36um-50pCB9_L5/dataset/', 
#'../Data/22-10-06-1.36um-100pFiller/dataset/']              

##Example dataset
datafolders = ['../example_dataset_snippet/testdataset/dataset/']


# Define the Following parameters:
framespersecond = 60            #Frames per second during the recording
fovwidth_um = 441               #known width of the field of view in um
fovwidth_px = 1280              #Width of the field of view in pixels 
minimum_displacement_um = 00    #Consider only those trajectories with a displacement of at least x um (we set this at 0 for the measurements in the article, but could be set higher if so desired.)
velocitycutoff_rolling = 0.5    #cutoff in um/s beyond which a particle is chosen to be rolling
minimum_nrof_frames = 30    

savgol_window = 20              #Window length used in the Savitzky-Golay filter of the velocities
savgol_poly = 5                 #polynomal order used in the Savitzky-Golay filter of the velocities


#Loop over the data folders
for dataindex,datafolder in enumerate(datafolders):

    datapoints = os.listdir(datafolder)
    nrs_rolling = np.array([])
    nrs_stuck = np.array([])

    #loop over every measurement within the datafolder
    for dataindex, datapoint in enumerate(datapoints):

        print(datapoint)
        #Load in the tracking parameters determined by 1.particletracking.py
        trackingparameters = np.loadtxt(datafolder + datapoint + "/analysis/trackingparameters.csv", skiprows=1,
                                        delimiter=',')
        time_per_frame = 1 / framespersecond
        um_per_px = fovwidth_um / fovwidth_px
        
        #Load in the particle trajectories determined by 1.particletracking.py
        t = pd.read_pickle(datafolder + datapoint + "/analysis/trajectories")

        particlelist = t.get('particle').to_numpy()
        particlesfound = int(t.max()['particle'])

        #initialize arrays for storing the stopping and rolling regime information.
        displacements_rollingregimes = np.array([])
        velocities_rollingregimes = np.array([])
        weights_rollingregimes = np.array([])
        particles_indices_rolling = np.array([])
        particles_indices_stopping = np.array([])
        weights_stoppingregimes = np.array([])

        times_rolling = np.array([])
        times_stopping = np.array([])

        #loop over all the particle trajectories found within the current measurement.
        for pindex in range(particlesfound):

            #First, we compute the absolute displacement of each particle.
            ptraj = t.loc[t['particle'] == pindex]
            xvals = ptraj.get('x').to_numpy()
            yvals = ptraj.get('y').to_numpy()
            frames = ptraj.get('frame').to_numpy()

            x_firstframe = xvals[0]
            y_firstframe = yvals[0]
            firstframe = frames[0] 

            x_displacement = xvals - x_firstframe
            y_displacement = yvals - y_firstframe
            frames_relative = frames - firstframe 

            #Compute the absolute displacement from the x and y displacement using Pythagoras' theorem.
            absolute_displacement = np.sqrt((x_displacement ** 2) + (y_displacement ** 2))

            #Convert displacement to um and time to s
            times_relative = np.multiply(frames_relative, time_per_frame)
            absolute_displacement_um = np.multiply(absolute_displacement, um_per_px)

            if frames_relative[-1]>minimum_nrof_frames: # If the particle was tracked for at least N=30 frames, proceed to analyse its trajectory

                if np.max(absolute_displacement_um) > minimum_displacement_um: #If the current particle has displaced more than the displacement threshold, continue with the analysis.

                    #Compute the velocity for each frame within the trajectory
                    Delta_displacement = absolute_displacement_um[1:] - absolute_displacement_um[:-1]
                    Delta_times = times_relative[1:] - times_relative[:-1]
                    velocity = np.divide(Delta_displacement, Delta_times)

                    #Smooth the velocities using a Savitzky–Golay filter. This is done to facilitate a better separation of the rolling and stopping regimes.
                    #Note, the savgol filter is only used to separate the rolling and stopping regimes, but the precise rolling velocities in the rolling regime are computed without the savgol filter applied.
                    velocity_smoothed = signal.savgol_filter(velocity, window_length=savgol_window, polyorder=savgol_poly, mode="nearest")

                    #Determine in which of the frames the velocity is above the rolling cut off, i.e. in which of the frames is the particle rolling?
                    velocity_above_threshold = velocity_smoothed > velocitycutoff_rolling

                    #Now, we use velocity_above_threshold to separate the trajectory into rolling and stopping regimes. 
                    transition = [] #This array will keep track of the transitions from rolling to stopping and vice-versa
                    #Loop over the velocity_above_threshold array to determine when the trajectory switches from stopping to rolling and vice versa. Append these points to the transition array
                    for counter, boolean in enumerate(velocity_above_threshold[:-1]):                   #loop over the frames in the trajectory
                        if velocity_above_threshold[counter] != velocity_above_threshold[counter + 1]:  #If the regime (stop or roll) of the next frame is different than that of the current frame, append the current frame nr to transition
                            transition.append(counter)
                    initialstate = velocity_above_threshold[0]                                          #Read out whether the initial frame is rolling or stopping

                    #define some arrays for data storage
                    rolling_timepoints = np.array([])
                    rolling_displacements = np.array([])
                    stopped_timepoints = np.array([])
                    stopped_displacements = np.array([])    

                    #Next, we use the transition array to split the trajectory data into rolling and stopping.
                    if initialstate == True: #if the first bit of the trajectory is rolling, we set countercheck to 0, otherwise it is set to 1.:
                        countercheck = 0
                    else:
                        countercheck = 1

                    #Loop over all the regimes, alternating between rolling and stopping windows. The parameter counter keeps track of whether the current window is rolling or stopping (rolling = even counter, stopped = odd counter)
                    for counter, Index in enumerate(transition[:-1]):

                        #If the current regime is a rolling regime, carry out the following
                        if not counter % 2 == countercheck:         
                            #Determine the left (a) and right (b) limit of the current rolling window within the trajectory.
                            a = transition[counter]
                            b = transition[counter + 1]

                            #Append the displacement values and time values to the array that stores the displacement and time windows
                            rolling_displacements=np.append(rolling_displacements,absolute_displacement_um[a:b])
                            rolling_timepoints=np.append(rolling_timepoints,times_relative[a:b])

                            #Compute the time difference and displacement difference across the current rolling window
                            time_rolling = times_relative[b] - times_relative[a]
                            displacement_rolling = absolute_displacement_um[b]-absolute_displacement_um[a]
                            weighing_factor = b-a   #The length of the window is used as a weighing factor to later average the rolling velocity

                            #Calculate the velocity in the current rolling window by dividing the displacements by the times.
                            velocity_rolling = displacement_rolling/time_rolling 

                            #Append the rolling time, displacement, velocity and weight of the current window to an array that stores these values.
                            times_rolling = np.append(times_rolling,time_rolling)
                            displacements_rollingregimes = np.append(displacements_rollingregimes,displacement_rolling)
                            particles_indices_rolling = np.append(particles_indices_rolling,pindex)
                            velocities_rollingregimes = np.append(velocities_rollingregimes,velocity_rolling)
                            weights_rollingregimes = np.append(weights_rollingregimes,weighing_factor)

                        #If the current regime is a stopping regime, carry out the following
                        else:   
                            #Determine the left (c) and right (d) limit of the current stopping window within the trajectory.
                            c = transition[counter]
                            d = transition[counter + 1]
                            time_stopping = times_relative[d] - times_relative[c]
                            weighing_factor = d - c

                            #Keep track of the displacements points and time points in the current regime
                            stopped_timepoints=np.append(stopped_timepoints,times_relative[c:d])
                            stopped_displacements=np.append(stopped_displacements,absolute_displacement_um[c:d])

                            #Store the stopping time of the current stopping regime and the weighing factor of the current stopping regime.
                            times_stopping = np.append(times_stopping,time_stopping)
                            particles_indices_stopping = np.append(particles_indices_stopping,pindex)
                            weights_stoppingregimes = np.append(weights_stoppingregimes,weighing_factor)

        if not os.path.exists(datafolder + datapoint + "/traces/"):
            os.makedirs(datafolder + datapoint + "/traces/")

        #Store the rolling and stopping information as csv files, for use in the next scripts.
        storagematrix_rolling = np.vstack((times_rolling,displacements_rollingregimes,velocities_rollingregimes,weights_rollingregimes,particles_indices_rolling)).T
        np.savetxt(datafolder + datapoint + '/traces/' + "rolling_information.csv",storagematrix_rolling,header="rollingtimes[s],rollingdisplacement[um],vrolling[um/s],weight[-],pindex[-]",delimiter=",")

        storagematrix_stopping = np.vstack((times_stopping,particles_indices_stopping,weights_stoppingregimes)).T
        np.savetxt(datafolder + datapoint + '/traces/' + "stopping_information.csv",storagematrix_stopping,header="stoppingtimes[s],pindex[-],weights[-]",delimiter=",")
