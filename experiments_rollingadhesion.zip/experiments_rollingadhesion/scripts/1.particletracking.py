from __future__ import division, unicode_literals, print_function  # for compatibility with Python 2 and 3

import os
import matplotlib as mpl
mpl.use('TkAgg')
import matplotlib.pyplot as plt
import numpy as np
import scipy
import time
import pims
import trackpy as tp
from scipy.ndimage import gaussian_filter


############################################################################################################################
#NOTE: This script reads the raw rolling adhesion movies, performs pre-processing steps, and stores particle trajectories. #
############################################################################################################################

###		Datapath settings		###
#Specify the path to the target dataset. Multiple paths can be provided using a list.

#Datasets used in the manuscript:
#datafolders = ['../Data/22-11-08-1.36um-50pSB/dataset/']       #thresholdintensity = 30 DONE   #Slip bond
#datafolders = ['../Data/22-11-16-1.36um-50pCB9_L7/dataset/']   #thresholdintensity = 30 DONE   #Catch bond
#datafolders = ['../Data/22-12-08-1.36um-50pCB9_L2/dataset/']   #thresholdintensity = 25 DONE   #Latch variation
#datafolders = ['../Data/22-12-01-1.36um-50pCB9_L3/dataset/']   #thresholdintensity = 35 DONE   #Latch variation
#datafolders = ['../Data/22-12-09-1.36um-50pCB9_L4/dataset/']   #thresholdintensity = 35 DONE   #Latch variation
#datafolders = ['../Data/22-12-14-1.36um-50pCB9_L5/dataset/']   #thresholdintensity = 45 DONE   #Latch variation
#datafolders = ['../Data/22-10-06-1.36um-100pFiller/dataset/']  #thresholdintensity = 40 DONE   #100pc FillerDNA control.

#Example dataset:
datafolders = ['../example_dataset_snippet/testdataset/dataset/'] #thresholdintensity = 40 DONE

# Data recording parameters
framespersecond = 60  		# frames per second used while collecting the data
nr_of_frames = 1634         #This is the total number of frames in each movie
channelwidth_microns = 441	# Width of the field of view in micrometers (used to determine the scale of the image)

filename = "/40x*/"			#Pre-amble of each video file frame
filetype = "*.bmp"			#File extension of each video file frame
analyze_frames = (0, nr_of_frames) #Specify which frames of the video to analyse. By default this is everything.
framestep = 1               # Analyze every x frames of the movie, by default this is one.
particleradius_um = 0.68    # micrometers, particle radius


###		Particle tracking parameters for Trackpy, see the trackpy locate function on http://soft-matter.github.io/trackpy/dev/generated/trackpy.batch.html?highlight=batch###
masksize = 9                # odd integer number. Mask size in pixels set by the localisation algorithm
minmass = 1                 # Minimal intensity for accepting localised spots
maxsize = 6                 # Maximal size

###		Preset parameters for trajectory linking, see the trackpy link function on: http://soft-matter.github.io/trackpy/dev/generated/trackpy.link.html?highlight=link:
memory = 2                  # Number of frames a particle may be unseen before it stops being tracked
distance = 2                # Distance in pixels a particle is allowed to move between two frames

###		Data pre-processing parameters for the background thresholding and the gaussian blur step.
thresholdintensity = 40     # Intensity cutoff for the background thresholding, chosen to be slightly larger than the background intensity, so that all the background is removed
Gaussianblurwidth = 1       # Width in pixels of the gaussian blur used to transform the thresholded brightfield spots into gaussian spots that can be tracked by trackpy

#Loop over each dataset.
for dataindex,datafolder in enumerate(datafolders):

    datasets = os.listdir(datafolder)

    # First, identify the borders of the field of view and the scale of the movie.
    borders_left = []
    borders_right = []
    for dataindex, dataset in enumerate(datasets):

        loadpath = datafolder + dataset + filename
        storepath = datafolder + dataset + '/analysis/'
        if not os.path.exists(storepath):
            os.makedirs(storepath)
        print("\n---- Loading designated dataset ----")
        try:
            frames = pims.open(loadpath + filetype)

            print("\n---- Dataset loaded succesfully, Continuing with analysis ----")
        except:
            print("\n----  Dataset not found, exiting... ---- ")
            quit()
        frames = frames[analyze_frames[0]:analyze_frames[1]:framestep]  #

        print("\n\n")
        channelleft = 0
        channelright = len(frames[0][0, :]) - 1
        channelwidth_px = channelright - channelleft
        time.sleep(1)

        micron_per_pixel = np.divide(channelwidth_microns, channelwidth_px) #Determine the scale of the pixels in the image, using the known field of view width in um.
        																	#"channelwidth" here refers to the width of the field of view.
        selectionleft = channelleft
        selectionright = channelright
        borders_left.append(selectionleft)
        borders_right.append(len(frames[0][0, :]) - selectionright)

    #Having established the borders of the movie, we now loop over every dataset to perform pre-processing and particle tracking.
    for dataindex, dataset in enumerate(datasets):

        loadpath = datafolder + dataset + filename
        storepath = datafolder + dataset + '/analysis/'

        if not os.path.exists(storepath):
            os.makedirs(storepath)
        print("\n---- Loading designated dataset ----")

        #load in each video, if it can be found:
        try:
            frames = pims.open(loadpath + filetype)
            print("\n---- Dataset loaded succesfully, Continuing with analysis ----")
        except:
            print("\n----  Dataset not found, exiting... ---- ")
            quit()

        # Crop the images. The cropping parameters can be set to remove parts of the field of view outside the channel if necessary. In the paper, no cropping was necessary, since the imaged window was a small area of 441 um exactly in the center of the 1500 um wide channel.
        frames = frames[analyze_frames[0]:analyze_frames[1]:framestep]
        frames = pims.process.crop(frames, ((0, 25), (borders_left[dataindex], borders_right[dataindex])))

        # change to float32 datatype:
        frames = np.array(frames)
        frames = frames.astype('float32')

        #Plot an image of the cropped first frame.
        print("\n---- 3. Cropping the selected boundaries from the images ----")
        time.sleep(1)
        figure, ax = plt.subplots(nrows=1, ncols=1, figsize=(16, 10))
        plt.subplots_adjust(left=0.18, wspace=0.38, hspace=0.38, top=0.92, bottom=0.19, right=0.93)
        midframe = round(len(frames) / 2)
        firstframe_cropped = frames[0]
        ax.imshow(firstframe_cropped, cmap="Greys_r")
        plt.savefig(storepath + "3.channelscropped.png", dpi=300)
        plt.close()

        #Next, we perform background thresholding to set all intensity below the threshold value to 0:
        print("\n ---- 4. Performing thresholding at threshold intensity " + str(thresholdintensity))
        shape = (len(frames), len(frames[0][:, 0]), len(frames[0][0, :]))
        for frindex, frame in enumerate(frames):
            above_threshold = np.where(frame > thresholdintensity)
            frames[frindex] = np.where(frame > thresholdintensity, frame, thresholdintensity)

        #plot an image of the first frame after thresholding.
        firstframe_thresholded = frames[0]
        figure, ax = plt.subplots(nrows=1, ncols=1, figsize=(16, 10))
        plt.subplots_adjust(left=0.18, wspace=0.38, hspace=0.38, top=0.92, bottom=0.19, right=0.93)
        ax.imshow(firstframe_thresholded, cmap="Greys_r")
        plt.savefig(storepath + "4.frames_thresholded.png", dpi=300)
        plt.close()

        #Perform a Gaussian blur of the remaining particle brightfield spots to convert truncated spots into gaussian particles to be tracked with trackpy
        print("\n---- 5. Performing a Gaussian blur of width " + str(
            Gaussianblurwidth) + " px ----")
        for fridx, frame in enumerate(frames):
            frames[fridx] = scipy.ndimage.filters.gaussian_filter(frames[fridx], Gaussianblurwidth)

        #Make a plot of the first frame after the gaussian blur step.
        firstframe_gaussianblurred = frames[0]
        figure, ax = plt.subplots(nrows=1, ncols=1, figsize=(16, 10))
        plt.subplots_adjust(left=0.18, wspace=0.38, hspace=0.38, top=0.92, bottom=0.19, right=0.93)
        midframe = round(len(frames) / 2)
        ax.imshow(firstframe_gaussianblurred, cmap="Greys_r")
        plt.savefig(storepath + "5.gaussian_blurred.png", dpi=300)
        plt.close()

        #Next, we rescale the blurred image on a scale of 0-255 intensity
        print("---- 6. Rescaling the blurred images ----")
        arrayminimum = np.amin(frames)
        arraymaximum = np.amax(frames)
        arrayrange = arraymaximum - arrayminimum

        for fridx, frame in enumerate(frames):
            frame = np.subtract(frame, arrayminimum)
            frame = np.divide(frame, arrayrange)
            frame = np.multiply(frame, 255)
            frames[fridx] = frame

        #Plot the rescaled image of the first frame.
        firstframe_rescaled = frames[0]
        figure, ax = plt.subplots(nrows=1, ncols=1, figsize=(16, 10))
        plt.subplots_adjust(left=0.18, wspace=0.38, hspace=0.38, top=0.92, bottom=0.19, right=0.93)
        ax.imshow(firstframe_rescaled, cmap="Greys_r")
        plt.savefig(storepath + "6.frames_rescaled.png", dpi=300)
        plt.close()

        #Now the pre-processing is completed. We then perform the particle tracking using trackpy.
        print("---- 7. Localizing features ----")
        print("\nParameters used by the localisation algorithm:\n-mask diameter: " + str(
            masksize) + " pixels\n-minimal mass: " + str(minmass) + "\n-maxsize: " + str(maxsize) + "\n-radius: " + str(
            particleradius_um) + " um")

        #Start tracking the features in the movie, using the settings set at the start of the script, with the trackpy batch function: http://soft-matter.github.io/trackpy/dev/generated/trackpy.batch.html?highlight=batch
        f = tp.batch(frames[:], processes=1, diameter=masksize, invert=False, noise_size=0, minmass=minmass,
                     maxsize=maxsize)

        del frames #Delete the frame images after tracking to free up some memory

        #Make a plot of the located features in the first frame, to check if the pre-processing steps went well
        print("---- 8. Plotting located features ----")
        figure, ax = plt.subplots(nrows=1, ncols=1, figsize=(16, 10))
        plt.subplots_adjust(left=0.18, wspace=0.38, hspace=0.38, top=0.92, bottom=0.19, right=0.93)
        ax.imshow(firstframe_rescaled, cmap="Greys_r")
        positions = f.loc[f['frame'] == 0]
        xpositions = positions.get('x').to_numpy()
        ypositions = positions.get('y').to_numpy()
        ax.scatter(xpositions, ypositions, c="r", s=0.1)
        plt.savefig(storepath + "8.features_localized.png", dpi=300)
        plt.close()

        #Link the tracked particles into trajectories using the trackpy link function http://soft-matter.github.io/trackpy/dev/generated/trackpy.link.html?highlight=link. 
        t = tp.link(f, distance, memory=memory)

        #Store the tracjectories as pickles.
        t.to_pickle(path=storepath + "trajectories")

        del f #delete the tracked particles from memory to free up some memory

        # Store the tracking parameters used in the particle tracking algorithm for future reference.
        trackingparameters = np.array(
            [framestep, channelleft, channelright, particleradius_um, masksize, minmass,
             maxsize, memory, distance, Gaussianblurwidth, thresholdintensity])
        np.savetxt(storepath + "trackingparameters.csv", trackingparameters, delimiter=',',
                   header='framestep (analysed every x frames),channelleft(px),channelright(px),particleradius (um),masksize (px), minmass (I), maxsize(px), memory (frames),distance(px),Gaussianblur width (px),thresholdintensity')

        del t #delete the trajectories from memory to free up some memory.
