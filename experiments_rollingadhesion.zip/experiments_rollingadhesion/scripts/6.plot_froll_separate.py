import os
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('TkAgg')
import matplotlib.pyplot as plt
from scipy import signal
from scipy import stats
from scipy.optimize import curve_fit
from scipy import asarray as ar, exp
from matplotlib.ticker import AutoMinorLocator,Locator
to_cm = 0.393701#inch to mm conversion

#####################################################################################################################################################################################################################################
#NOTE: This script takes the trajectories found by 1.particletracking.py, and determines the fraction of rolling particles f_roll. 
#Particles moving more than a threshold displacement of 1 um over the course of their trajectory are considered rolling. 
#Next, a separate plots of f_roll versus shearrates are made, like the ones in figure 4b of the manuscript.
#To plot the overlayed f_roll versus shearrate plots like the one in figure 2c of the manuscript, please use 6.overlay_froll_SB_CB.py
######################################################################################################################################################################################################################################

######datasets used in the manuscript:
datafolders = ['../Data/22-11-08-1.36um-50pSB/dataset/'] 
#'../Data/22-11-16-1.36um-50pCB9_L7/dataset/'
#'../Data/22-12-08-1.36um-50pCB9_L2/dataset/'
#'../Data/22-12-01-1.36um-50pCB9_L3/dataset/'
#'../Data/22-12-09-1.36um-50pCB9_L4/dataset/'
#'../Data/22-12-14-1.36um-50pCB9_L5/dataset/'

####Example dataset:
datafolders = ['../example_dataset_snippet/testdataset/dataset/']


# PARAMETERS
framespersecond = 60            #Framerate used during data collection
channelwidth_um = 441           #Width of the field of view in micrometers  Used to determine the distance scale in the image
channelwidth_px = 1280          #Width of the field of view in pixels. Used to determine the distance scale in the image

channel_height = 50             #um. Used to calculate the shear rate from the flow rate
channel_width = 1500            #um. Used to calculate the shear rate from the flow rate

minimum_displacement_um = 1     #Threshold for the rolling. If a particle moved more than minimum_displacement_um over the course of its trajectory it is considered rolling 
minimum_nrof_frames = 30        #Threshold nr of frames a particle should be tracked in order to be considered rolling or stopped

#Set color of the plots (Grey for slip bond, green for catch bond)
colors=[
"#747575",  #Grey for slip bond data
#"#4682b4"  #Green for the latch variations
]

#Set marker shape: square for slip bonds, circle for catch bonds.
markers=[
"s",
#"o"
]

#Set dataset names.
names = [
"slipbond"
#"Latch_2",
#"Latch_3",
#"Latch_4",
#"Latch_5",
#"Latch_7"
]

#Loop over every dataset in the datafolder
for folderindex,datafolder in enumerate(datafolders):

    datapoints = os.listdir(datafolder)

    #Initialize an array for storing the numbers rolling and numbers stuck at every flowrate
    nrs_rolling = np.array([])
    nrs_stuck = np.array([])
    values = np.array([])

    #loop over each measurement within the dataset
    for dataindex, datapoint in enumerate(datapoints[:]):
        print(datapoint)

        #Read out the imposed flowrate
        value = datapoint.split('ulmin')
        rate = value[0]
        value_int = float(rate)
       
        #Compute the shear rate corresponding to the current flowrate
        t = np.multiply(value_int, pow(10, 8))
        b = np.multiply(pow(channel_height, 2), channel_width)
        shear_rate = round(t / b)
        values = np.append(values, shear_rate)

        #Calculate time in seconds and distance in micrometers.
        time_per_frame = 1 / framespersecond
        um_per_px = channelwidth_um / channelwidth_px

        #Read out the particle trajectories from the tracking data
        t = pd.read_pickle(datafolder + datapoint + "/analysis/trajectories")
        particlelist = t.get('particle').to_numpy()
        particlesfound = int(t.max()['particle'])

        nr_particles_rolling = 0
        nr_particles_stuck = 0

        #Loop over all the particle trajectories, to count the nr of particles rolling and stuck
        for pindex in range(particlesfound):

            ptraj = t.loc[t['particle'] == pindex]

            #The next bit determines the displacement of the particle over its trajectory
            xvals = ptraj.get('x').to_numpy()
            yvals = ptraj.get('y').to_numpy()
            frames = ptraj.get('frame').to_numpy()

            x_firstframe = xvals[0]
            y_firstframe = yvals[0]
            firstframe = frames[0] 

            x_displacement = xvals - x_firstframe
            y_displacement = yvals - y_firstframe
            frames_relative = frames - firstframe

            #Calculate the absolute displacement using pythagoras' theorem.
            absolute_displacement = np.sqrt((x_displacement ** 2) + (y_displacement ** 2))

            #convert time and displacement to seconds and micrometers, respectively.
            times_relative = np.multiply(frames_relative, time_per_frame)
            absolute_displacement_um = np.multiply(absolute_displacement, um_per_px)

            #Only take into account trajectories that are off sufficient length: items tracked for more than 0.5 s in this case.
            if frames_relative[-1]>minimum_nrof_frames:
                #If a particle displaces further than the target minimal displacement, it is considered rolling. Otherwise, it is considered stuck
                if np.max(absolute_displacement_um) > minimum_displacement_um:
                    nr_particles_rolling+=1
                else:
                    nr_particles_stuck+=1

        nrs_rolling = np.append(nrs_rolling,nr_particles_rolling)
        nrs_stuck = np.append(nrs_stuck,nr_particles_stuck)

    #Normalize the fractions
    totalnrs = np.add(nrs_stuck,nrs_rolling)
    f_roll = np.divide(nrs_rolling,totalnrs)

    #Plot a figure.
    fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(6*to_cm, 7.5*to_cm)) #figsize=(3.6, 3.2) figsize=(5, 5)
    plt.subplots_adjust(left=0.15, wspace=0.38, hspace=0.38, top=0.98, bottom=0.15, right=0.98)
    ax.tick_params(axis='y',**{'which':'major','width':2.3,'length':6,'direction':'in','left':True,'right':True})
    ax.tick_params(axis='y',**{'which':'minor','width':1.7,'length':3,'direction':'in','left':True,'right':True})  
    ax.tick_params(axis='x',**{'which':'major','width':2.3,'length':6.5,'direction':'in','bottom':True,'top':True})    
    ax.tick_params(axis='x',**{'which':'minor','width':1.7,'length':3.5,'direction':'in','bottom':True,'top':True})
    [line.set_linewidth(1.6) for line in ax.spines.values()]

    #Plot the fraction of stuck particles f_roll over the shearrate
    plt.scatter(values, f_roll,marker=markers[0], color=colors[0],s=60)

    for tick in ax.xaxis.get_major_ticks():
        tick.label.set_fontsize(19)
    for tick in ax.yaxis.get_major_ticks():
        tick.label.set_fontsize(19)

    plt.rcParams['font.size'] = '16'
    ax.xaxis.set_minor_locator(AutoMinorLocator(2))
    ax.yaxis.set_minor_locator(AutoMinorLocator(2))

    #set axis limites
    plt.xlim(xmin=0,xmax=1300)
    plt.ylim(ymin=0,ymax=1)

    plt.xlabel(r"$\dot{\gamma}\ [\mathrm{s}^{-1}]}$",fontsize=26)
    plt.ylabel(r"$f_{roll}$", fontsize=26)

    plt.savefig("f_roll_"+names[folderindex]+".svg")
    print("\n-------- Figure saved as: f_roll_"+names[folderindex]+".svg -------\n")
    plt.show()
    plt.close()
