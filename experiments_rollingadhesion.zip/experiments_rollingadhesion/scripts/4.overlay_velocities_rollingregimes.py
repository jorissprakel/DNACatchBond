import os
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import AutoMinorLocator,Locator
to_cm = 0.393701#inch to mm conversion

#########################################################################################################################################################
#NOTE: This script takes the mean rolling velocities determined by 3.analyze_velocities_rollingregimes.py 
#This script only plots overlayed v_roll vs gammadot graphs, like the one used in fig. 2e of the manuscript.
#Please use 4.plot_velocities_rollingregimes.py to plot separate v_roll vs gamma dot graphs like the one shown in figure 4 of the manuscript
#########################################################################################################################################################


#datasets used in the manuscript:
resultfolders = ['../Data/22-11-08-1.36um-50pSB/results/',      #Slip bond dataset
                '../Data/22-11-16-1.36um-50pCB9_L7/results/']   #catch bond dataset (Nlatch=7)

####Example dataset:
resultfolders = ['../example_dataset_snippet/testdataset/results/']

#Plot a figure
fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(7*to_cm, 7.5*to_cm)) #figsize=(3.6, 3.2) figsize=(5, 5)
plt.subplots_adjust(left=0.15, wspace=0.38, hspace=0.38, top=0.98, bottom=0.15, right=0.98)
ax.tick_params(axis='y',**{'which':'major','width':2.2,'length':6,'direction':'in','left':True,'right':True})
ax.tick_params(axis='y',**{'which':'minor','width':1.5,'length':3,'direction':'in','left':True,'right':True})  
ax.tick_params(axis='x',**{'which':'major','width':1.9,'length':6.5,'direction':'in','bottom':True,'top':True})    
ax.tick_params(axis='x',**{'which':'minor','width':1.3,'length':3.5,'direction':'in','bottom':True,'top':True})
[line.set_linewidth(1.6) for line in ax.spines.values()]

colors = [
"#747575",  #Grey, for slip bond
"#26931f"   #Green, for catch bond
]

markers=[
"s",        #square for slip bond
"o"         #round for catch bond.
]

#loop over the resultfolders.
counter = 0
for Rindex, resultfolder in enumerate(resultfolders):

    counter += 1

    #Read the means from the csv files stored by 3.analyze_velocities_rollingregimes.py
    means_path = resultfolder + "Gaussian_Means_weighted.csv"
    means_data = pd.read_csv(means_path, sep=",", skiprows=0)
    df_numpy = means_data.to_numpy(dtype='float32')
    means = df_numpy[:, 1]

    #Read the standard deviations from the csv files stored by 3.analyze_velocities_rollingregimes.py
    SD_path = resultfolder + "Gaussian_Standard_Deviations_weighted.csv"
    sigma_data = pd.read_csv(SD_path, sep=",", skiprows=0)
    df_numpy = sigma_data.to_numpy(dtype='float32')
    sigma = df_numpy[:, 1]

    #Read the shearrate from the csv files stored by 3.analyze_velocities_rollingregimes.py
    flowrate_path = resultfolder + "Gaussian_Standard_Deviations_weighted.csv"
    flowrate = pd.read_csv(flowrate_path, sep=",", skiprows=0)
    df_numpy = flowrate.to_numpy(dtype='float32')
    values = df_numpy[:, 0]

    color = colors[Rindex]

    print(values)

    #Plot the means
    plt.scatter(x=values, y=means, c=color,marker = markers[Rindex])

    #Plot the standard deviation windows with the fill_between function of matplotlib.
    y_high = means+sigma
    y_low = means-sigma
    plt.fill_between(values, y_low, y_high,color=color,edgecolor=None,alpha=0.3)

    for tick in ax.xaxis.get_major_ticks():
        tick.label.set_fontsize(18)
    for tick in ax.yaxis.get_major_ticks():
        tick.label.set_fontsize(18)

    ax.xaxis.set_minor_locator(AutoMinorLocator(2))
    ax.yaxis.set_minor_locator(AutoMinorLocator(2))

    plt.rcParams['font.size'] = '16'
    #Set axis limits.
    plt.ylim(ymin=0, ymax=6)
    plt.xlim(xmin=0, xmax=1300)
    
    plt.xlabel(r"$\dot{\gamma}\ [\mathrm{s}^{-1}]}$",fontsize=22) 
    plt.ylabel(r"$v_{roll}\ [\mu\mathrm{m/s]}$", fontsize=22)
    plt.legend(loc="upper right",frameon=False,handlelength=0.001)

#Store the plot as a csv
plt.savefig("v_roll_overlayed.svg")
plt.show()
plt.close()
