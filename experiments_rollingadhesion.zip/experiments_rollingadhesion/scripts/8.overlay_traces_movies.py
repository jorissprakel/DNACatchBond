from __future__ import division, unicode_literals, print_function  # for compatibility with Python 2 and 3
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pandas import DataFrame, Series  # for convenience
import scipy.optimize as fit
from scipy import signal
import os
import time
import pims
from matplotlib.ticker import AutoMinorLocator,Locator
mpl.use('TkAgg')

######################################################################################################################################################
#NOTE
#This script loads the particle trajectories analyzed by 1.particletracking.py and overlays them over the raw movie frames
#to generate the movies in supplementary videos 3 (slip bonds) and 4 (catch bonds 9_latch7)
#The colorcoded traces are plotted in a 'traces_SV_tr' subfolder of the dataset, such as: '../Data/22-11-16-1.36um-50pCB9_L7/dataset/20.00ulmin/analysis/traces_SV_tr/"' OR '../Data/example_dataset_snippet/dataset/35.0ulmin/analysis/traces_SV_tr/'
#The resulting overlayed traces are stored as .png files and can be loaded in imagej to export them as .avi movies.

###################################################################################################################################################

###Datasets used in the manuscript:
#datafolder = '../Data/22-11-08-1.36um-50pSB/dataset/' 			#Slip bond
#datafolder = '../Data/22-11-16-1.36um-50pCB9_L7/dataset/'		#Catch bond 9_L7

###Example dataset:
datafolder = '../example_dataset_snippet/testdataset/dataset/'

###Parameters:
nr_of_frames = 1634					#Total number of frames in the dataset
framespersecond = 60				#Framerate used during data collection
frameskip = 10 						#plot every x frames
frames_trace = (0,1633)

channelwidth_um = 441 				#width of the channel in micrometers. This is used to convert distances in pixels to distances in um.
channelwidth_px = 1280 				#width of the channel in pixels.

velocitycutoff_rolling = 0.5  		#um/s. Threshold used to separate rolling from stopped particles
nr_frames_threshold = 30			#Sets the minimum length in frames a particle must be tracked in order to be considered.
dpi = 100							#Resolution for storing the images.
plot_tracelines = True 				#If true: Plots a yellow trace line behind each particle.

############################################################################################

#Set scales in time (s) and distance (um)
time_per_frame = 1 / framespersecond
um_per_px = channelwidth_um / channelwidth_px

#Loop over all the measurements within the datafolder.
datapoints = os.listdir(datafolder)
for dataindex,datapoint in enumerate(datapoints):

	#load in the movie of a single measurement.
	try:
		frames_im = pims.open(datafolder+datapoint+'/40x*/*.bmp')				#Load the movie datapoints
		print("\n---- Dataset loaded succesfully, Continuing with analysis ----")
	except:
		print("\n----  Dataset not found, exiting... ---- ")
		quit()

	#Load the tracking parameters determined by 1.particletracking.py
	trackingparameters=np.loadtxt(datafolder+datapoint+"/analysis/trackingparameters.csv",skiprows=1,delimiter=',')	
	framestep = int(trackingparameters[0])
	frames_im = pims.process.crop(frames_im,((0,25),(0,0)))

	#Set the storage path for th color-coded traces.
	tracepath = datafolder+datapoint+"/analysis/traces_SV_tr/"				#storagepath for the data
	if not os.path.exists(tracepath):
		os.makedirs(tracepath)

	#read out the particle trajectories 
	t = pd.read_pickle(datafolder+datapoint+"/analysis/trajectories").sort_values(by=['particle','frame'])
	#Add an additional boolean column called "state" to the trajectory, that will hold the rolling (true) or stopping (false) information		
	t['state']=None 
	print(t)

	particlelist = t.get('particle').to_numpy()#[1,2,3]#								
	particlesfound = int(t.max()['particle'])								

	#First, we loop over all the particles found in the trajectory, and determine in which frames they can be considered rolling or stopped, using the savitzky golay filter and the rolling cutoff, as in 2.rolling_analysis_separateregimes.py
	state_information = np.array([])	
	for pindex in range(particlesfound+1):

		ptraj = t.loc[t['particle']==pindex]
		xvals = ptraj.get('x').to_numpy()
		yvals = ptraj.get('y').to_numpy()
		frames = ptraj.get('frame').to_numpy()

		#First, we check if particle trajectories are longer than the threshold length to be considered (nr_frames_threshold=30). Particles shorter than this length are labeled separately.
		if len(frames)<nr_frames_threshold: 
			state_information = np.append(state_information,2*np.ones(len(frames)))

		#For particle trajectories longer than the threshold, we determine the rolling/stopping states over time:
		else:
			#We first determine the velocity information of the particle in every frame
			x_firstframe = xvals[0]
			y_firstframe = yvals[0]
			firstframe = frames[0] 

			x_displacement = xvals - x_firstframe
			y_displacement = yvals - y_firstframe
			frames_relative = frames - firstframe 

			#Calculate the displacement using pythagoras' theorem.
			absolute_displacement = np.sqrt((x_displacement ** 2) + (y_displacement ** 2))

			#Convert time to s and displacement to micrometers.
			times_relative = np.multiply(frames_relative, time_per_frame)
			absolute_displacement_um = np.multiply(absolute_displacement, um_per_px)

			#From displacement and time, determine the velocity:
			Delta_displacement = absolute_displacement_um[1:] - absolute_displacement_um[:-1]
			Delta_times = times_relative[1:] - times_relative[:-1]
			velocity = np.divide(Delta_displacement, Delta_times)
			#Using the savitzky-golay filter we smoothe the velocity information, as in 2.rolling_analysis_separateregimes.
			velocity_smoothed = signal.savgol_filter(velocity, window_length=20, polyorder=5, mode="nearest")

			#After smoothing, we separate the trajectories into rolling and stopped with the threshold we applied
			velocity_above_threshold = velocity_smoothed > velocitycutoff_rolling
			velocity_above_threshold = np.append(velocity_above_threshold,velocity_above_threshold[-1]).astype(int)

			#print(velocity_above_threshold)

			#Rolling and stopped information is then stored in the state information column of the trajectory 
			state_information = np.append(state_information,velocity_above_threshold) #Append the rolling and stopped information to the state information array

	t['state']=state_information #Plug in the state information into the trajectory dataframe

	#Next, we plot the images, as follows:
	figure,ax=plt.subplots(nrows=1,ncols=1,figsize = (12,10))
	plt.subplots_adjust(left= 0.05,wspace=0.38, hspace=0.38,top=0.92,bottom = 0.07, right = 0.93)
	ax.set_aspect(1)

	print(framestep)
	print(nr_of_frames)
	print(tracepath)

	tracestepper=0
	#Loop over all the frames
	for framenr in range(frames_trace[0],frames_trace[1],framestep*frameskip):

		print(framenr)
		framestepper = framenr
		#First plot the raw images
		ax.imshow(frames_im[framenr],cmap="Greys_r",vmax=70)

		if not framenr == 0:
			tracestepper = round(framenr/framestep)

		t_particles = t.loc[t['particle'].isin(particlelist)]
		#Find all the particles in the current frame
		t_particles_infr = t_particles.loc[t_particles['frame']==tracestepper]#.sort_values(by='particle')
		#Find all rolling, stopped and not determined particles in this frame, using the state column that we just added.
		t_particles_infr_roll = t_particles_infr.loc[t_particles_infr['state']==1.]#.sort_values(by='particle')
		t_particles_infr_stop = t_particles_infr.loc[t_particles_infr['state']==0.]#.sort_values(by='particle')
		t_particles_infr_none = t_particles_infr.loc[t_particles_infr['state']==2.]#.sort_values(by='particle')

		#Plot rolling particles as green circles
		xpositions_roll = t_particles_infr_roll.get('x').to_numpy()
		ypositions_roll = t_particles_infr_roll.get('y').to_numpy()
		ax.scatter(xpositions_roll,ypositions_roll,s=40,facecolors='none',edgecolors='#26931f')

		#Plot stopped particles as red circles
		xpositions_stop = t_particles_infr_stop.get('x').to_numpy()
		ypositions_stop = t_particles_infr_stop.get('y').to_numpy()
		ax.scatter(xpositions_stop,ypositions_stop,s=40,facecolors='none',edgecolors='#A31418')

		#Plot trajectories shorter than the threshold (30 frames) as black circles
		xpositions_none = t_particles_infr_none.get('x').to_numpy()
		ypositions_none = t_particles_infr_none.get('y').to_numpy()
		ax.scatter(xpositions_none,ypositions_none,s=40,facecolors='none',edgecolors='k')

		#if we choose to plot the tracelines, do the following:
		if plot_tracelines:

			#Determine which particles in previous frames are also present in the current frame.
			t_particles_untilframe = t_particles.loc[t_particles['frame']<=tracestepper]
			ps_to_trace = t_particles_untilframe['particle'].unique()
			
			for index,p in enumerate(ps_to_trace):

				#Determine the location of the current particle in all frames prior to the current frame.
				trace_particle = t_particles_untilframe.loc[t_particles_untilframe['particle']==p].sort_values(by='frame')
				xpos_trace = trace_particle.get('x').to_numpy()
				ypos_trace = trace_particle.get('y').to_numpy()

				#Plot this displacement over time as a yellow line.
				ax.plot(xpos_trace,ypos_trace,linewidth=0.5,color="y")

		#Store the frame of the movie:		
		if not os.path.exists(tracepath+"/"):
			os.makedirs(tracepath+"/")
		plt.savefig(tracepath+"/"+str(framenr)+".png",dpi=100)
		ax.cla()

	plt.close()
