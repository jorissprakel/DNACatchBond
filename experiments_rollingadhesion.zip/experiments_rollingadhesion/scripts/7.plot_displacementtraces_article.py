import os
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('TkAgg')
import matplotlib.pyplot as plt
from scipy import signal
from scipy import stats
from scipy.optimize import curve_fit
from scipy import asarray as ar, exp
from matplotlib.ticker import AutoMinorLocator,Locator
to_cm = 0.393701#inch to mm conversion

#####################################################################################################################################################################################################################################
#NOTE: Note, this script plots a series of displacement traces, like the ones in figure 2D, and supplementary figures S4 and S4 in the manuscript.
#It takes particle trajectories determined by 1.particletracking.py, separates the trajectories into rolling and stopping regimes in the same way as 2.rolling_analysis_separateregimes.py
#And then plots each color-coded trajectory in a 'traces' subfolder of the dataset, such as: '../Data/22-11-16-1.36um-50pCB9_L7/dataset/20.00ulmin/traces/displacement/'

######################################################################################################################################################################################################################################


###  datasets used in the manuscript:
datafolders = ['../Data/22-11-08-1.36um-50pSB/dataset/']    #slip bond 
#'../Data/22-11-16-1.36um-50pCB9_L7/dataset/'               #catch bond
#'../Data/22-12-08-1.36um-50pCB9_L2/dataset/'               #latch variation
#'../Data/22-12-01-1.36um-50pCB9_L3/dataset/'               #latch variation
#'../Data/22-12-09-1.36um-50pCB9_L4/dataset/'               #latch variation
#'../Data/22-12-14-1.36um-50pCB9_L5/dataset/'               #latch variation
#'../Data/22-10-06-1.36um-100pFiller/dataset/'              #100pc FillerDNA control.

###  Example dataset
datafolders = ['../example_dataset_snippet/testdataset/dataset/']


# PARAMETERS
framespersecond = 60            #Framerate used in data collection
channelwidth_um = 441           #width of channel in um (determine the scale in um)
channelwidth_px = 1280          #width of channel in px (determine the scale in um)
minimum_displacement_um = 00    #Minimum displacement for a particle trajectory to be plot. Here we set this to 0, but could be set differently if desired
velocitycutoff_rolling = 0.5    #velocity cutoff that separates rolling vs stopped regime, in um/s. same as in 2.rolling_analysis_separateregimes.py
minimum_nrof_frames = 30        #Minimum length of the trajectory (nr of frames) in order to be considered in the analysis

plot_dataindices = range(10000) #Sets the maximum nr of trajectories you want to plot per dataset. Set to a low value to plot a small subset, or a very high value (e.g. range(1e6)) to plot every trajectory. 
                                #You can also input a list with specific indices, to plot a specific subset, e.g.: [3,10,233] etc.

#Loop over all the datasets in the datafolder
for findex,datafolder in enumerate(datafolders):
    datapoints = os.listdir(datafolder)

    #Loop over every measurement within a dataset
    for dataindex, datapoint in enumerate(datapoints):
        print(datapoint)

        #Check if the trace is one you want to plot (see plot_dataindices)
        if dataindex in plot_dataindices:

            #Determine the scales: time per frame and um per pixel
            time_per_frame = 1 / framespersecond
            um_per_px = channelwidth_um / channelwidth_px

            #Load in the trajectory determined by 1.particletracking.py
            t = pd.read_pickle(datafolder + datapoint + "/analysis/trajectories")

            particlelist = t.get('particle').to_numpy()
            particlesfound = int(t.max()['particle'])

            #initialize arrays for storring the rolling and stopping information.
            displacements_rollingregimes = np.array([])
            velocities_rollingregimes = np.array([])
            weights_rollingregimes = np.array([])
            particles_indices_rolling = np.array([])
            particles_indices_stopping = np.array([])
            weights_stoppingregimes = np.array([])

            #Loop over all the particles
            for pindex in range(particlesfound):
                if pindex != None:

                    ptraj = t.loc[t['particle'] == pindex]

                    #The next bit calculates the displacement of the current particle
                    xvals = ptraj.get('x').to_numpy()
                    yvals = ptraj.get('y').to_numpy()
                    frames = ptraj.get('frame').to_numpy()

                    x_firstframe = xvals[0]
                    y_firstframe = yvals[0]
                    firstframe = frames[0] 

                    x_displacement = xvals - x_firstframe
                    y_displacement = yvals - y_firstframe
                    frames_relative = frames - firstframe 

                    #Compute the absolute displacement using pythagoras' theorem
                    absolute_displacement = np.sqrt((x_displacement ** 2) + (y_displacement ** 2))

                    #Convert time to seconds and displacement to um
                    times_relative = np.multiply(frames_relative, time_per_frame)
                    absolute_displacement_um = np.multiply(absolute_displacement, um_per_px)

                    if frames_relative[-1]>minimum_nrof_frames: #Only consider a trajectory if it is of length at least 30 frames. (see minimum_nrof_frames)
                        if np.max(absolute_displacement_um) > minimum_displacement_um:  #Plots those traces with a displacement greater than minimum_displacement_um

                            #############################################################################################################################
                            #Next, we use the same protocol as used in 2.rolling_analysis_separateregimes.py to separate the rolling and stopped regimes.
                            #Please see 2.rolling_analysis_separateregimes.py for a detailed description of the protocol.
                            #############################################################################################################################

                            Delta_displacement = absolute_displacement_um[1:] - absolute_displacement_um[:-1]
                            Delta_times = times_relative[1:] - times_relative[:-1]

                            velocity = np.divide(Delta_displacement, Delta_times)
                            velocity_smoothed = signal.savgol_filter(velocity, window_length=20, polyorder=5, mode="nearest")

                            velocity_above_threshold = velocity_smoothed > velocitycutoff_rolling

                            transition = []
                            for counter, boolean in enumerate(velocity_above_threshold[:-1]):
                                if velocity_above_threshold[counter] != velocity_above_threshold[counter + 1]:
                                    transition.append(counter)
                            initialstate = velocity_above_threshold[0]

                            rolling_timepoints = np.array([])
                            rolling_displacements = np.array([])

                            stopped_timepoints = np.array([])
                            stopped_displacements = np.array([])

                            if initialstate == True:    #if the first bit of the trajectory is rolling:
                                countercheck = 0
                            else:
                                countercheck = 1

                            for counter, Index in enumerate(transition[:-1]):

                                if not counter % 2 == countercheck: #If the current trajectory is rolling
                                    a = transition[counter]
                                    b = transition[counter + 1]

                                    rolling_displacements=np.append(rolling_displacements,absolute_displacement_um[a:b])
                                    rolling_timepoints=np.append(rolling_timepoints,times_relative[a:b])

                                    time_rolling = times_relative[b] - times_relative[a]
                                    displacement_rolling = absolute_displacement_um[b]-absolute_displacement_um[a]
                                    weighing_factor = b-a

                                    velocity_rolling = displacement_rolling/time_rolling

                                else:   #If the current trajectory is stopping
                                    c = transition[counter]
                                    d = transition[counter + 1]
                                    time_stopping = times_relative[d] - times_relative[c]
                                    weighing_factor = d - c

                                    stopped_timepoints=np.append(stopped_timepoints,times_relative[c:d])
                                    stopped_displacements=np.append(stopped_displacements,absolute_displacement_um[c:d])

                            #Having split the current trajectory into rolling and stopping regimes, we now plot the displacement trace::
                            if len(stopped_timepoints)>0 or len(stopped_displacements)>0: #Plot the displacement curves in case rolling or stopping regimes were found.
                                
                                #Initiate a figure:
                                fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(7.2*to_cm, 7.5*to_cm)) #figsize=(3.6, 3.2) figsize=(5, 5)
                                plt.subplots_adjust(left=0.25, wspace=0.38, hspace=0.38, top=0.98, bottom=0.21, right=0.98)
                                ax.tick_params(axis='y',**{'which':'major','width':2.2,'length':6,'direction':'in','left':True,'right':True})
                                ax.tick_params(axis='y',**{'which':'minor','width':1.5,'length':3,'direction':'in','left':True,'right':True})  
                                ax.tick_params(axis='x',**{'which':'major','width':1.9,'length':6.5,'direction':'in','bottom':True,'top':True})    
                                ax.tick_params(axis='x',**{'which':'minor','width':1.3,'length':3.5,'direction':'in','bottom':True,'top':True})
                                [line.set_linewidth(1.6) for line in ax.spines.values()]

                                for tick in ax.xaxis.get_major_ticks():
                                    tick.label.set_fontsize(18)

                                for tick in ax.yaxis.get_major_ticks():
                                    tick.label.set_fontsize(18)

                                ax.xaxis.set_minor_locator(AutoMinorLocator(5))
                                ax.yaxis.set_minor_locator(AutoMinorLocator(2))

                                plt.rcParams['font.size'] = '16'
                                
                                #Plot the stopped and rolling timepoints in red and green
                                plt.scatter(stopped_timepoints, stopped_displacements,s=13, color="#af3131", label="Stopped")
                                plt.scatter(rolling_timepoints, rolling_displacements,s=13, color='#279320', label="Rolling")
                                
                                #Set axis limits.
                                ax.set_xlim(left = 0)
                                ax.set_ylim(bottom = -0.1,top=7)

                                plt.xlabel(r"$t\ \mathrm{[s]}$", fontsize=22)
                                plt.ylabel(r"$\Delta x\ [\mu\mathrm{m]}$", fontsize=22)
                                
                                storepath = datafolder + datapoint + "/traces/displacement/" 
                                if not os.path.exists(storepath):
                                    os.makedirs(storepath)

                                #Plot the trace in the designated folder, as a png file.
                                plt.savefig(storepath+"trace_" + str(pindex) + ".png",dpi=100)
                                plt.close()
