from __future__ import division, unicode_literals, print_function

import numpy as np
import matplotlib.pylab as plt
from matplotlib.ticker import AutoMinorLocator,Locator
from matplotlib import cm
from matplotlib.colors import rgb2hex
import pickle as pk
import os


#####################################################################################

#NOTE: This scripts takes in the average tstops analysed by 5.analyze_tstop.py
#for both the slip bond simulation and the catch bond simulation, and plots t_roll vs shearrate for both of these, to generate a figure like fig. 3E of the manuscript
#Please make sure the simulations of both the slip bond dataset and the catch bond dataset have been fully analysed by 1.stop_versus_roll_interp.py, followed by 5.analyze_tstop.py
#before running this script.

#####################################################################################

#Relative location of the stopvroll information for the slipbond data (element 1) and for the catch bond data (element 2)
datafiles = ['../analysis/stop_vs_roll/plots/stoptimes_vs_shearrates.csv',
'../../catchbond_rollsimulations/analysis/stop_vs_roll/plots/stoptimes_vs_shearrates.csv']

#Set plot colours
colors = [
"#747575",	#grey for slip bonds
"#a31519"	#red for catch bonds
]

#Set markers
markers=[
"s",
"o"
]

#Initiate a matplotlib figure
fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(3, 2.5)) #figsize=(3.6, 3.2) figsize=(5, 5)
plt.subplots_adjust(left=0.25, wspace=0.38, hspace=0.38, top=0.92, bottom=0.15, right=0.93)
ax.tick_params(axis='y',**{'which':'major','width':2.2,'length':6,'direction':'in','left':True,'right':True})
ax.tick_params(axis='y',**{'which':'minor','width':1.5,'length':3,'direction':'in','left':True,'right':True})  
ax.tick_params(axis='x',**{'which':'major','width':1.9,'length':6.5,'direction':'in','bottom':True,'top':True})    
ax.tick_params(axis='x',**{'which':'minor','width':1.3,'length':3.5,'direction':'in','bottom':True,'top':True})
[line.set_linewidth(1.6) for line in ax.spines.values()]

#Loop over the datafiles
for dataindex, datafile in enumerate(datafiles):

	#load in the stoptimes vs shearrates information
	data = np.loadtxt(datafile,delimiter=',',skiprows=1)
	shearrates = data[:,0]
	stoptimes = data[:,1]
	stdevs = data[:,2]

	#plot the standard deviations as filled areas with the matplotlib fill between function
	y_high = stoptimes+stdevs
	y_low = stoptimes-stdevs
	plt.fill_between(shearrates, y_low, y_high,color=colors[dataindex],edgecolor=None,alpha=0.3)

	#plot the datapoints as scatters
	plt.scatter(shearrates,stoptimes,c=colors[dataindex],marker = markers[dataindex])#,color=colors[dataindex])


for tick in ax.xaxis.get_major_ticks():
	tick.label.set_fontsize(16)
for tick in ax.yaxis.get_major_ticks():
	tick.label.set_fontsize(16)

ax.xaxis.set_minor_locator(AutoMinorLocator(2))

#Set the xticks and y limits
ax.set_xticks([0,1000,2000])
plt.rcParams['font.size'] = '12'
ax.set_ylim(bottom = 10**(0),top=3*10**2)
ax.set_yscale("log")

ax.set_xlabel(r'$\dot{\gamma}$',fontsize=19)
ax.set_ylabel(r'$t_{stop}$',fontsize=19,rotation="vertical")

#Store the figure.
plt.savefig("tstop_vs_shearrate.svg")
plt.show()
plt.close()


