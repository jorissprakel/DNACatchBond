import os
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import AutoMinorLocator,Locator
to_cm = 0.393701#inch to mm conversion

#####################################################################################

#NOTE: This scripts takes in the average rolling velocities analysed by 2.analyze_rollingregimes.py
#for both the slip bond simulation and the catch bond simulation, and plots v_roll vs shearrate for both of these, to generate a figure like fig. 3D of the manuscript
#Please make sure the simulations of both the slip bond dataset and the catch bond dataset have been fully analysed by 1.stop_versus_roll_interp.py, followed by 2.analyze_rollingregimes
#before running this script.

#####################################################################################

#Specify the datafolders of the simulated slip bond and catch bond data.
datafolders = ['../analysis/stop_vs_roll/plots/',
'../../catchbond_rollsimulations/analysis/stop_vs_roll/plots/']

colormap = cm.get_cmap('plasma', 255)

#Build a matplotlib figure
fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(3, 2.5)) #figsize=(3.6, 3.2) figsize=(5, 5)
plt.subplots_adjust(left=0.25, wspace=0.38, hspace=0.38, top=0.92, bottom=0.15, right=0.93)
ax.tick_params(axis='y',**{'which':'major','width':2.2,'length':6,'direction':'in','left':True,'right':True})
ax.tick_params(axis='y',**{'which':'minor','width':1.5,'length':3,'direction':'in','left':True,'right':True})  
ax.tick_params(axis='x',**{'which':'major','width':1.9,'length':6.5,'direction':'in','bottom':True,'top':True})    
ax.tick_params(axis='x',**{'which':'minor','width':1.3,'length':3.5,'direction':'in','bottom':True,'top':True})
[line.set_linewidth(1.6) for line in ax.spines.values()]

#Define plot colours
colors = [
"#747575", #(grey for slip)
"#26931f"   #(green for catch)
]

#Define plot markers
markers=[
"s",
"o"
]

#loop over both the slip bond and catch bond data.
counter = 0
for Rindex, resultfolder in enumerate(datafolders):

    counter += 1

    #Read in the mean v_roll from 2.analyze_rollingvelocities.py
    means_path = resultfolder + "Gaussian_Means_weighted.csv"
    means_data = pd.read_csv(means_path, sep=",", skiprows=0)
    df_numpy = means_data.to_numpy(dtype='float32')
    means = df_numpy[:, 1]

    #Read in the standard deviations from 2.analyze_rollingvelocities.py
    SD_path = resultfolder + "Gaussian_Standard_Deviations_weighted.csv"
    sigma_data = pd.read_csv(SD_path, sep=",", skiprows=0)
    df_numpy = sigma_data.to_numpy(dtype='float32')
    sigma = df_numpy[:, 1]

    #read in the shearrates
    shearrate_path = resultfolder + "Gaussian_Standard_Deviations_weighted.csv"
    shearrate = pd.read_csv(shearrate_path, sep=",", skiprows=0)
    df_numpy = shearrate.to_numpy(dtype='float32')
    values = df_numpy[:, 0]

    #Make the scatter plots
    color = colors[Rindex]
    plt.scatter(x=values, y=means, c=color,marker = markers[Rindex])

    #use the matplotlib fill_between function to plot the standard deviation as an area.
    y_high = means+sigma
    y_low = means-sigma
    plt.fill_between(values, y_low, y_high,color=color,edgecolor=None,alpha=0.3)

    for tick in ax.xaxis.get_major_ticks():
        tick.label.set_fontsize(15)
    for tick in ax.yaxis.get_major_ticks():
        tick.label.set_fontsize(16)

    ax.xaxis.set_minor_locator(AutoMinorLocator(2))
    ax.yaxis.set_minor_locator(AutoMinorLocator(2))

    #set axis limits
    plt.ylim(ymin=-0.02, ymax=0.4)
    ax.set_xticks([0,1000,2000])

    plt.rcParams['font.size'] = '15'
    
    plt.xlabel(r"$\dot{\gamma}}$",fontsize=19) 
    plt.ylabel(r"$v_{roll}}$", fontsize=19)

#Store the figure.
plt.savefig("vroll_vs_shearrate.svg")
plt.show()
plt.close()
