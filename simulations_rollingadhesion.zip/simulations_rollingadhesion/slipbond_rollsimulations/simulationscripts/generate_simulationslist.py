

def generate_simulationslist(basepairs,stresses,nr_simulations):

	print(nr_simulations)
	simulationslst = range(0,nr_simulations)

	lstfile = open('simulationslist.txt','w')
	for BP in basepairs:
		for elem in stresses:
			for nr in simulationslst:
				lstfile.write(str(BP)+' '+str(elem)+' '+str(nr)+'\n')
	
	lstfile.close()
