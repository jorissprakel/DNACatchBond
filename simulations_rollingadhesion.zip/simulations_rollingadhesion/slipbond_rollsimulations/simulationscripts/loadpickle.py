import pickle as pk
import numpy as np
import sys

picklefile = sys.argv[1]

with open(picklefile, 'rb') as pickle_file:
	data=pk.load(pickle_file)

print(data)