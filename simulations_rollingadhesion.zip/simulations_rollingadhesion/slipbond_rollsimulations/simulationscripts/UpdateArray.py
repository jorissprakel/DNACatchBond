from __future__ import division, unicode_literals, print_function
import numpy as np

def UpdateArray(linkers,F,par):

	if par['attachmentdirection'] == 0:	#normal to bottom surface
		Rmax = np.sqrt(np.square(par['a'])-np.square(par['h']-par['Lmax']))

	else:								#if attachment direction is normal to bead surface
		amax = np.arccos(np.divide(par['h'],par['a']+par['Lmax']))
		Rmax = np.multiply(par['h'],np.tan(amax))

	dr = 1/np.sqrt(par['rho'])			#typical distance between particles. Depends on the density rho on the surface

	#remove pillars on the left:
	if np.min(linkers.p0[:,0])<(-1)*(Rmax+3*dr):
		ii1 = np.where(linkers.p0[:,0]<0)[0]														#Find nodes with an x position smaller than 0
		ii2 = np.where((np.square(linkers.p0[:,0])+np.square(linkers.p0[:,1]))>np.square(Rmax))[0]	#Find nodes at least Rmax removed from the center of the bead
		ii = np.intersect1d(ii1,ii2)																#Find the intersect of conditions ii1 and ii2, these are nodes to remove
		ikeep = np.setdiff1d(np.arange(np.shape(linkers.p0)[0]),ii)									#The remaining nodes are nodes to keep

		linkers.p0 = linkers.p0[ikeep,:]
		linkers.p1 = linkers.p1[ikeep,:]

		linkers.connected = linkers.connected[ikeep]
		F = F[ikeep]

	#Add extra linkers (if so specified):
	if np.max(linkers.edge[:,0])<(Rmax+dr):
		ddr = par['linkerpositionnoise']*dr

		if par['extralinkers']>0:
			nadd = par['extralinkers']

			for i in range(len(linkers.edge[:,0])):	#add nadd tethers in each row
				xadd = linkers.edge[i,0] + dr* np.array(range(1,nadd+1))[np.newaxis].T+ddr* (1-2*np.random.rand(nadd,1))
				yadd = linkers.edge[i,1] *np.ones((nadd,1)) +ddr* (1-2*np.random.rand(nadd,1))

				newlinkersp0s = np.hstack((xadd,yadd))
				linkers.p0 = np.vstack((linkers.p0,newlinkersp0s))
				linkers.edge[i,0]=xadd[-1]

				newconnections = np.zeros((nadd,1),dtype=bool)
				linkers.connected = np.append(linkers.connected,newconnections)

				newp1array = np.zeros((nadd,3),dtype=float)
				linkers.p1 = np.vstack((linkers.p1,newp1array))

				newFarray = np.zeros((nadd,1),dtype=float)
				F = np.vstack((F,newFarray))

	return(linkers,F)