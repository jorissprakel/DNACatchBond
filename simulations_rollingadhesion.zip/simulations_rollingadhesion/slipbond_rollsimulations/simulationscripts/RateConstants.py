from __future__ import division, unicode_literals, print_function
import numpy as np


def RateConstants(linkers,par,F):

	#Obtain the rate constants: kon/koff depending on whether tether is connected.
	#F is pased for eff

	k = np.zeros((np.shape(linkers.p0)[0],1))

	#off-rates
	k[linkers.connected]=par['koff0']*np.exp(par['del']*F[linkers.connected]) #no division by KT??

	#on-rates
	if par['attachmentdirection']==0:	#In case the attachment direction is normal to the surface
		R=par['h']-np.sqrt(np.square(par['a']) - (np.square(linkers.p0[linkers.connected!=True,0]) + linkers.p0[linkers.connected!=True,1])) #Distance to bead surface
	else:
		r=np.sqrt(np.square(linkers.p0[linkers.connected!=True,0]) + np.square(linkers.p0[linkers.connected!=True,1]))
		r[r==0] = 1e-10 #If r is practically zero, set r to a very low value, to avoid divisions by zero
		alpha=np.arctan(r/par['h'])
		R=np.divide(r,np.sin(alpha))-par['a']

	if par['polymermodel']==1: #ideal chain
		dG=3*np.square(R)/(par['Lmax']*par['lK'])
	else: #WLC
		x=R/par['Lmax']

		Fi = (2/par['lK'])*(np.divide(0.25,np.square(1-x))-0.25+x-0.8*np.power(x,2.15))
		dG = (2/par['lK'])*(np.divide(0.25*np.square(x),(1-x))+0.5*np.square(x)-(0.8/3.15)*np.power(x,3.15))

		A=Fi*par['del']-dG
		A[A>0]=0
		A[x>1]=-np.inf

	kon = par['kon0']*np.exp(A)
	kon.shape = (np.shape(kon)[0],1)

	k[linkers.connected!=True]=kon

	return(k)
