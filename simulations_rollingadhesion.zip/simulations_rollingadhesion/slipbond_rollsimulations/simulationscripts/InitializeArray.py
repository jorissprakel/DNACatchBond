from __future__ import division, unicode_literals, print_function
import numpy as np

def InitializeArray(par):

	#Initialize a class with linkers and create sub-parameters:
	#
	#p0:		x-y coordinates on bottom surface
	#p1:		x-y-z coordinates on bead surface (for attached linkers)
	#connected: boolean array listing attached linkers
	#edge: x-y coordinates of edge of array (at the front)


	class linker:
		def __init__(self,p0,p1,connected,edge):
			self.p0=p0
			self.p1=p1
			self.connected=connected
			self.edge=edge

	if par['attachmentdirection']==0: #normal to bottom surface
		Rmax = np.sqrt(np.square(par['a'])-np.square(par['h']-par['Lmax']))
	else:							#normal to bead surface
		amax = np.arccos(np.divide(par['h'],(par['a']+par['Lmax'])))
		Rmax = par['h']*np.tan(amax)

	dr = 1/np.sqrt(par['rho']) #Average distance between linkers

	#Create an array of linker coordinates (origin at bead center)
	rj = np.arange(start=-Rmax-dr,stop=Rmax,step=dr)

	p=np.array([])
	edge=np.array([])

	for j in range(len(rj)):

		xj = rj
		yj = rj[j]*np.ones(len(xj))

		pj = np.transpose(np.vstack([xj,yj]))
		pj = pj[np.square(pj[:,0])+np.square(pj[:,1])<np.square(Rmax),:]

		if pj.any():

			if not p.any():
				p = pj[:]
			else:
				p=np.vstack([p,pj])

		if np.shape(pj)[0]>0:

			if not edge.any():
				edge = pj[-1,:]
			else:
				edge = np.vstack([edge,pj[-1,:]])

	#Add extra tethers on the right
	if par['extralinkers']>0: #create extra
		nadd=par['extralinkers']
		for i in range(len(edge)): #add nadd tethers in each row

			xadd = (edge[i,0]+ dr*np.transpose(range(1,nadd+1))[np.newaxis]).T
			yadd = edge[i,1]*np.ones((nadd,1))
			newps=np.hstack([xadd,yadd])

			p = np.vstack([p,newps])
			
			edge[i,0]=xadd[-1]

	#add noise to linker positions
	ddr = par['linkerpositionnoise']*dr
	p = p + ddr*(1-2*np.random.rand(np.shape(p)[0],np.shape(p)[1]))

	#Calculate distance L to bead surface:
	if par['attachmentdirection']==0: #Normal to bottom surface

		L = par['h'] - np.sqrt(np.square(par['a'])-(np.square(p[:,0])+np.square(p[:,1])))

	else:	#Normal to particle surface
		r = np.sqrt(np.square(p[:,0]) + np.square(p[:,1]))
		r[r==0] = 1e-10		#if r =0, set to a very low value to avoid divisions by 0
		alpha = np.arctan(r/par['h'])
		L = np.divide(r,np.sin(alpha))-par['a']

	x = np.divide(L,par['Lmax']) #Extension of the polymers relative to contour length
	#Randomly bind linkers with probability K/(1+K) with K=(kon/koff)^0*exp(-DeltaG_el/kT)

	if par['polymermodel']==1: #ideal chain
		dG = np.divide(3*np.square(L),par['Lmax']*par['lK'])
		
	if par['polymermodel']==2: #WLC
		dG = (2/par['lK'])*(np.divide(0.25*np.square(x),1-x)+0.5*np.square(x)-(0.8/3.15)*np.power(x,3.15))


	dG[x>0.99]=np.inf #remove overstretched chains
	
	#Next, we calculate the on-rate for every linker as follows:
	K0 = par['kon0']/par['koff0']
	K = K0*np.exp(-dG)						

	connected = np.random.rand(np.shape(p)[0])< np.divide(K,1+K)		#connect with the probability K/(1+K) connected, forms a list of booleans that specify which of the linkers is connected

	#next, actually connect the tethers by setting the positions p1 on the bead that they connect to!

	p1 = np.zeros((np.shape(p)[0],3))

	if par['attachmentdirection']==0:	#if attachment direction is set normal to the surface
		L=L[np.newaxis].T
		p1[connected,:] = np.hstack([p[connected,:],L[connected,:]])

	else:								#If attachment direction is set normal to the particle surface
		
		r1 = par['a']*np.sin(alpha)

		p1[connected,0] = np.divide(np.multiply(p[connected,0],r1[connected]),r[connected])
		p1[connected,1] = np.divide(np.multiply(p[connected,1],r1[connected]),r[connected])

		z1 = par['h']-par['a']*np.cos(alpha)

		p1[connected,2]=z1[connected]

	#Finally: Store the linkers in a new class
	linkers = linker(p0=p,p1=p1,connected=connected,edge=edge)
	return linkers
