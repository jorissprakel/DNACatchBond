import os
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import AutoMinorLocator,Locator


#####################################################################################

#NOTE: This scripts takes in rolling regimes analyzed by 1.stop_versus_roll_interp.py and computes the average tstop and the standard deviation of tstop
#The resulting mean tstop and standard deviation are stored in stoptimes_vs_shearrate.csv
#and can then be read by 6.overlay_tstop_vs_shearrate.py to plot the figure 3E of the manuscript: The overlayed rolling tstop for catch bonds and slip bonds.

#####################################################################################

#location of the stop_vs_roll regime information
datafolder = '../analysis/stop_vs_roll/'

#Density value set during the simulation
densityvalues = [2000]

#Flowrates set during the simulation
flowrates = np.array([110,100,90,80,70,60,50,40,35,30,25,20,15,10,5])

#Convert flowrates to shearrates
flowrate_to_stress = 6.67440969                 #kbt/um3 with channel dimensions of 50 um height, 1500 um wide, 2 cm long, in water at 20 C
stressvalues = np.round(np.multiply(flowrates,flowrate_to_stress),2)
viscosity = 0.001   #Pa s, for converting stress to gammadot, as: gammadot = stress/viscosity 
flowrates = stressvalues/6.6744 
shearstresses_Pa = flowrates*(0.266667/10)
shearrates_smin1 = shearstresses_Pa/viscosity

#Loop over the densities
for densityindex, density in enumerate(densityvalues):
    densityname = "density_"+str(density)
    
    stoptimes_averages = np.array([])
    stoptimes_stdevs = np.array([])

    #loop over the shear stresses (=flowrates)
    for stressindex,stress in enumerate(stressvalues):
        stressvaluename = "stress_"+str(stress)

        #Read in the stopping information analyzed by 1.stop_versus_roll_interp.py
        stopping_information = np.loadtxt(datafolder+densityname+"/"+stressvaluename+"/stopping_information.csv",delimiter = ",", skiprows = 1)
        stoppingtimes = stopping_information[:,0]

        #compute the average stoptime and stdev
        stoptime_average = np.average(stoppingtimes)
        stoptime_stdev = np.std(stoppingtimes)

        #append the average stoptime and stdev to the array with stoptimes and stdevs.
        stoptimes_averages = np.append(stoptimes_averages,stoptime_average)
        stoptimes_stdevs = np.append(stoptimes_stdevs,stoptime_stdev)

    if not os.path.exists(datafolder+"plots/"):
        os.makedirs(datafolder+"plots/")

    #store the stoptimes and stdevs for further plotting with 6.overlay_tstop_vs_shearrate.py
    storagematrix = np.vstack((shearrates_smin1,stoptimes_averages,stoptimes_stdevs)).T
    np.savetxt(datafolder +"stoptimes_vs_shearrate.csv",storagematrix,header="shearrate,tstop_avg,tstop_stdev",delimiter=",")
