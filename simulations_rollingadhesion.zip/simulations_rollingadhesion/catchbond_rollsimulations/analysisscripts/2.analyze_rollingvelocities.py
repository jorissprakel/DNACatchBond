import os
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import AutoMinorLocator,Locator
from scipy.optimize import curve_fit

#####################################################################################

#NOTE: This scripts takes in rolling regimes analyzed by 1.stop_versus_roll_interp.py and computes the weighted gaussian mean and standard deviation of the v_roll in the rolling regimes.
#The resulting mean vroll and standard deviation are stored in datafolder/plots/Gaussian_Means_weighted.csv
#and can then be read by 3.overlay_vroll_vs_shearrate.py to plot the figure 3D of the manuscript: The overlayed rolling velocities for catch bonds and slip bonds.

#####################################################################################

#Path to the data folder:
datafolder = '../analysis/stop_vs_roll/'

#density values used in the simulation
densityvalues = [2000]
#flowrates used in the simulation
flowrates = np.array([110,100,90,80,70,60,50,40,35,30,25,20,15,10,5])

#Convert flowrate to shear rate
flowrate_to_stress = 6.67440969                 #kbt/um3 with channel dimensions of 50 um height, 1500 um wide, 2 cm long, in water at 20 C
stressvalues = np.round(np.multiply(flowrates,flowrate_to_stress),2)
viscosity = 0.001   #Pa s, for converting stress to gammadot, as: gammadot = stress/viscosity 
flowrates = stressvalues/6.6744 
shearstresses_Pa = flowrates*(0.266667/10)
shearrates_smin1 = shearstresses_Pa/viscosity

#Loop over all the bond densities simulated (in our manuscript only 1)
for densityindex, density in enumerate(densityvalues):
	densityname = "density_"+str(density)

	#initiate arrays for storing the data
	ps_half = []
	Gaussian_Means = np.array([])
	Gaussian_Standard_Deviations = np.array([])
    
   	#Loop over the stress values
	for stressindex,stress in enumerate(stressvalues):
		stressvaluename = "stress_"+str(stress)

		#load in the rolling information analysed by 1.stop_vs_roll_interp.py
		rolling_information = np.loadtxt(datafolder+densityname+"/"+stressvaluename+"/rolling_information.csv",delimiter = ",", skiprows = 1)
		rollingtimes = rolling_information[:,0]
		displacement_rollingregimes =rolling_information[:, 1]
		velocities_rollingregimes=rolling_information[:, 2]
		weights_rollingregimes=rolling_information[:, 3]
		repeats_indices=rolling_information[:, 4]
		displacement_rollingregimes = displacement_rollingregimes[velocities_rollingregimes>0.001]
		weights_rollingregimes = weights_rollingregimes[velocities_rollingregimes>0.001]
		repeats_indices = repeats_indices[velocities_rollingregimes>0.001]
		rollingtimes = rollingtimes[velocities_rollingregimes>0.001]
		velocities_rollingregimes = velocities_rollingregimes[velocities_rollingregimes>0.001]

		#construct a histogram of the rolling velocities v_roll weighted proportionally according to the durations of the rolling regimes.			
		bin_sequence = np.arange(np.min(velocities_rollingregimes), np.max(velocities_rollingregimes) + bin_spacing, bin_spacing)
		hist, binedges = np.histogram(velocities_rollingregimes, weights=weights_rollingregimes, bins=bin_sequence)

		#Compute the mean rolling velocities and the standard deviation.
		mean = np.average(velocities_rollingregimes)
		sigma = np.std(velocities_rollingregimes)

		#append the mean value to the array of gaussian means
		Gaussian_Means = np.append(Gaussian_Means, mean)
		Gaussian_Standard_Deviations = np.append(Gaussian_Standard_Deviations, sigma)


	if not os.path.exists(datafolder+"plots/"):
		os.makedirs(datafolder+"plots/")

	#store the gaussian means and standard deviations in a csv file.
	storagematrix_means = np.vstack((shearrates_smin1, Gaussian_Means)).T
	np.savetxt(datafolder + "plots/Gaussian_Means_weighted.csv", storagematrix_means, header = "ShearRate, Gaussian_Mean", delimiter=",")
	storagematrix_SD = np.vstack((shearrates_smin1, Gaussian_Standard_Deviations)).T
	np.savetxt(datafolder + "plots/Gaussian_Standard_Deviations_weighted.csv", storagematrix_SD, header = "ShearRate, Gaussian_SD", delimiter=",")
