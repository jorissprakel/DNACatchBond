from __future__ import division, unicode_literals, print_function
import numpy as np
import matplotlib.pylab as plt
from matplotlib.ticker import AutoMinorLocator,Locator
from matplotlib import cm
from matplotlib.colors import rgb2hex
from scipy import signal
import pickle as pk
import os
to_cm = 0.393701#inch to mm conversion
plasma = cm.get_cmap('plasma_r', 255)

#######################################################################################################################################################
#NOTE This script takes the particle location over the course of a series of simulations and divides its trajectory into stopping and rolling regimes,
#Before the regime separation, the particle position information is linearly interpolated, because the kinetic monte carlo simulations are event driven and therefore do not provide data linear in time.
#This script outputs csv files with rolling and stopping information from the regimes.

#################################################################################################################################################################

#Specify the location of the data folder
datafolder = "../simulation"
#Set the simulation density used
densityvalues = [2000]
#set the number of repeats specified
reps = 100

#Set the velocity cutoff used to separate rolling and stopping regimes
velocitycutoff_rolling = 0.01
#Set the timestep of the linear interpolation of the data
interpolate_timesteps = 0.1

#Define whether colored displacement traces should be plotted.
colored_displacements = True

#using the viscosity, convert the defined flowrates to shearrate values.
viscosity = 0.001	
flowrates = np.array([110,100,90,80,70,60,50,40,35,30,25,20,15,10,5])
flowrate_to_stress = 6.67440969					#kbt/um3 with channel dimensions of 50 um height, 1500 um wide, 2 cm long, in water at 20 C
stressvalues = np.round(np.multiply(flowrates,flowrate_to_stress),2)
flowrates = stressvalues/6.6744 
shearstresses_Pa = flowrates*(0.266667/10)
shearrates = shearstresses_Pa/viscosity

#loop over the simulation densities
for densityindex, density in enumerate(densityvalues):
	densityname = "density_"+str(density)
	
	#Loop over the simulation stresses
	for stressindex,stress in enumerate(stressvalues):
		stressvaluename = "stress_"+str(stress)

		times_rolling = np.array([])
		displacements_rollingregimes = np.array([])
		velocities_rollingregimes = np.array([])
		weights_rollingregimes = np.array([])
		repeats_rollingregimes = np.array([])
		
		stopped_timepoints=np.array([])
		stopped_displacements=np.array([])
		times_stopping = np.array([])
		weights_stoppingregimes = np.array([])
		repeats_stoppingregimes = np.array([])

		#loop over the simulation repeats
		for repeat in range(reps):

			repname = "rep_"+str(repeat)

			colorvalue = plasma((stress-min(stressvalues))/(max(stressvalues)-min(stressvalues)+2))
			
			#For each repeat, read out the time information and the bead position information xbead
			logfilename=datafolder+"/"+densityname+"/"+stressvaluename+"/"+repname+"/log.csv"
			logfile = np.loadtxt(logfilename,delimiter=",",skiprows=1)
			time = logfile[:,1]
			x_bead = logfile[:,3]

			#First, we perform the linear interpolation betweeen the times and xpositions:
			times_interpolate = np.arange(start = 0, stop = np.max(time),step=interpolate_timesteps)
			x_bead_interp = np.array([])
			for t_ind, t_interp in enumerate(times_interpolate):

				index_next = np.argmax(time>t_interp)
				index_previous = index_next-1

				t_next = time[index_next]
				t_previous = time[index_previous]

				x_next = x_bead[index_next]
				x_previous = x_bead[index_previous]

				slope = (x_next-x_previous)/(t_next-t_previous)
				x_bead_interp = np.append(x_bead_interp, x_previous+slope*(t_interp-t_previous))

			Delta_displacement = x_bead_interp[1:]-x_bead_interp[:-1]
			Delta_times = times_interpolate[1:]-times_interpolate[:-1]

			#next, we separate the data into stopping and rolling regimes, similar to the experimental analysis. (see the description of the rolling adhesion experimental analysis: 2.rolling_analysis_separateregimes.py for more information)
			velocity = np.divide(Delta_displacement,Delta_times)
			velocity_smoothed = signal.savgol_filter(velocity, window_length=20, polyorder=5, mode="nearest")
			velocity_above_threshold = velocity_smoothed > velocitycutoff_rolling

			transition = [0]		#Make an array that keeps track of between which steps the particle transitions from rolling to stopping and vice-versa
			for counter, boolean in enumerate(velocity_above_threshold[:-1]):
				if velocity_above_threshold[counter]!=velocity_above_threshold[counter+1]:
					transition.append(counter)

			initialstate = velocity_above_threshold[0]

			rolling_timepoints = np.array([])
			rolling_displacements = np.array([])

			stopped_timepoints = np.array([])
			stopped_displacements = np.array([])

			if initialstate == True: #If starting out as rolling
				countercheck = 0
			else:
				countercheck = 1

			for counter,Index in enumerate(transition[:-1]):
				if counter % 2 == countercheck: #If the current trajectory is rolling

					a = transition[counter]
					b = transition[counter + 1]

					if b-a>1:

						rolling_displacements = np.append(rolling_displacements,x_bead_interp[a:b])
						rolling_timepoints = np.append(rolling_timepoints,times_interpolate[a:b])

						time_rolling = times_interpolate[b]-times_interpolate[a]
						displacement_rolling = x_bead_interp[b]-x_bead_interp[a]
						weighing_factor = b-a

						velocity_rolling = displacement_rolling/time_rolling

						times_rolling = np.append(times_rolling,time_rolling)
						displacements_rollingregimes = np.append(displacements_rollingregimes,displacement_rolling)
						velocities_rollingregimes = np.append(velocities_rollingregimes,velocity_rolling)
						weights_rollingregimes = np.append(weights_rollingregimes,weighing_factor)
						repeats_rollingregimes = np.append(repeats_rollingregimes,repeat)

				else:   #If the current trajectory is stopping
					
					c = transition[counter]
					d = transition[counter + 1]

					if d-c>1:
						time_stopping = times_interpolate[d] - times_interpolate[c]
						weighing_factor = d - c

						stopped_timepoints=np.append(stopped_timepoints,times_interpolate[c:d])

						stopped_displacements=np.append(stopped_displacements,x_bead_interp[c:d])
						times_stopping = np.append(times_stopping,time_stopping)
						weights_stoppingregimes = np.append(weights_stoppingregimes,weighing_factor)
						repeats_stoppingregimes = np.append(repeats_stoppingregimes,repeat)

			if transition == [0]: #Sometimes the particle is stationary throughout the experiment. In this case, no transition is found between stopping and rolling and hence all frames are stopped.
				if initialstate == True: #If starting out as rolling
					rolling_displacements = np.append(rolling_displacements,x_bead_interp[:])
					rolling_timepoints = np.append(rolling_timepoints,times_interpolate[:])

					time_rolling = times_interpolate[-1]-times_interpolate[0]
					displacement_rolling = x_bead_interp[-1]-x_bead_interp[0]
					weighing_factor = np.shape(times_interpolate)[0]

					velocity_rolling = displacement_rolling/time_rolling
					times_rolling = np.append(times_rolling,time_rolling)

					displacements_rollingregimes = np.append(displacements_rollingregimes,displacement_rolling)
					velocities_rollingregimes = np.append(velocities_rollingregimes,velocity_rolling)
					weights_rollingregimes = np.append(weights_rollingregimes,weighing_factor)
					repeats_rollingregimes = np.append(repeats_rollingregimes,repeat)

				elif initialstate == False: #If starting out as stopped
					time_stopping = times_interpolate[-1] - times_interpolate[0]
					weighing_factor = np.shape(times_interpolate)[0]
					stopped_timepoints=np.append(stopped_timepoints,times_interpolate[:])
					stopped_displacements=np.append(stopped_displacements,x_bead_interp[:])
					times_stopping = np.append(times_stopping,time_stopping)
					weights_stoppingregimes = np.append(weights_stoppingregimes,weighing_factor)
					repeats_stoppingregimes = np.append(repeats_stoppingregimes,repeat)

			#if we decided to store the displacement traces.
			if colored_displacements:
				
				if not os.path.exists("../analysis/colored_traces/"+densityname+"/"+stressvaluename+"/"):
					os.makedirs("../analysis/colored_traces/"+densityname+"/"+stressvaluename+"/")

				#Define a figure.
				fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(7.2*to_cm, 7.5*to_cm)) #figsize=(3.6, 3.2) figsize=(5, 5)
				plt.subplots_adjust(left=0.30, wspace=0.38, hspace=0.38, top=0.94, bottom=0.21, right=0.98)
				ax.tick_params(axis='y',**{'which':'major','width':2.2,'length':6,'direction':'in','left':True,'right':True})
				ax.tick_params(axis='y',**{'which':'minor','width':1.5,'length':3,'direction':'in','left':True,'right':True})  
				ax.tick_params(axis='x',**{'which':'major','width':1.9,'length':6.5,'direction':'in','bottom':True,'top':True})    
				ax.tick_params(axis='x',**{'which':'minor','width':1.3,'length':3.5,'direction':'in','bottom':True,'top':True})
				[line.set_linewidth(1.6) for line in ax.spines.values()]

				plt.rcParams['font.size'] = '16'

				#if plot the rolling and stopping information
				plt.scatter(stopped_timepoints, stopped_displacements,s=13, color="#af3131", label="Stopped")
				plt.scatter(rolling_timepoints, rolling_displacements,s=13, color='#279320', label="Rolling")

				for tick in ax.xaxis.get_major_ticks():
				    tick.label.set_fontsize(18)
				for tick in ax.yaxis.get_major_ticks():
				    tick.label.set_fontsize(18)

				ax.xaxis.set_minor_locator(AutoMinorLocator(5))
				ax.yaxis.set_minor_locator(AutoMinorLocator(2))

				#set axis limits
				ax.set_ylim(bottom=0.0,top=2.0)
				ax.set_xlim(left=0.0)

				plt.xlabel(r"$t$", fontsize=22)
				plt.ylabel(r"$\Delta s$", fontsize=22)

				#Save the coloured trace!
				plt.savefig("../analysis/colored_traces/"+densityname+"/"+stressvaluename+"/" + str(repeat) + ".png",dpi=300)
				
				plt.close()

			if not os.path.exists("../analysis/stop_vs_roll/"+densityname+"/"+stressvaluename+"/"):
				os.makedirs("../analysis/stop_vs_roll/"+densityname+"/"+stressvaluename+"/")

			#Finally, save the rolling and stopping information in csv files, for further plotting
			storagematrix_rolling = np.vstack((times_rolling,displacements_rollingregimes,velocities_rollingregimes,weights_rollingregimes,repeats_rollingregimes)).T
			np.savetxt("../analysis/stop_vs_roll/"+densityname+"/"+stressvaluename+"/rolling_information.csv",storagematrix_rolling,header="rollingtimes,rollingdisplacement,vrolling,weight,repeatindex",delimiter=",")

			storagematrix_stopping = np.vstack((times_stopping,weights_stoppingregimes,repeats_stoppingregimes)).T
			np.savetxt("../analysis/stop_vs_roll/"+densityname+"/"+stressvaluename+"/stopping_information.csv",storagematrix_stopping,header="stoppingtimes,weights,repeatindex",delimiter=",")
