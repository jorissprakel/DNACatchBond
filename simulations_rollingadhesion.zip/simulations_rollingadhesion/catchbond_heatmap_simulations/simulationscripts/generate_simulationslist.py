

###########################################################

#NOTE: This script is called by generate_measurementarchitecture.py
#It generates a list of simulations called simulationslist.txt
#When the batch of simulations is started through the SLURM task manager through initiate_jobarrayparallel.sh,
#this script loops over the items in simulationslist.txt to start each simulation.

#####################################################################



def generate_simulationslist(densities,stresses,nr_simulations):

	print(nr_simulations)
	simulationslst = range(0,nr_simulations)

	lstfile = open('simulationslist.txt','w')
	for density in densities:
		for elem in stresses:
			for nr in simulationslst:
				lstfile.write(str(density)+' '+str(elem)+' '+str(nr)+'\n')
	
	lstfile.close()
