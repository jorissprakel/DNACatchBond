import numpy as np
import os
import generate_simulationslist
import generate_input
import random


##################################################################

#### NOTE: This script generates the simulation architecture for the catch bond series from which we compute the heat map. 
#### On top, we set simulation parameters 
#### The output is a folder called "simulation" which contains a subfolder for each of the simulation repeats. 
#### each of these subfolders contains the input files necessary to run the rolling particle simulations
#### After running this script, a simulation can be started individually by running the input files with run_simulation.py from the command line: "run_simulation.py path/to/inputfile/ input.txt"
#### For the manuscript, we performed the list of simulations in bulk, using the SLURM scheduler and the initiate_jobarrayparallel.sh file

########MAIN PARAMETERS OF THE SIMULATION SERIES##############

flowrates = np.array([140])							#Flowrate at which we performed the heat map simulation

bonds_per_um2 = np.array([2000])

#Convert flowrate to stress
flowrate_to_stress = 6.67440969						#kbt/um3 with channel dimensions of 50 um height, 1500 um wide, 2 cm long, in water at 20 C
stresses = np.round(np.multiply(flowrates,flowrate_to_stress),2)

nr_simulations = 20									#Number of repeated simulations per stress
MaxSteps = 1000000									#Number of simulation steps per simulation
print_steps = 5000									#Print an update on the state of the simulation (positions and forces on the linkers) every x steps
log_steps = 100										#Print an update to the log file every x steps

#Initiate a database to plug in all the defined parameters
database = {}
database.update({"stresses":stresses})
unitvector = np.ones(len(database["stresses"]))
nr_repeats = unitvector*nr_simulations
nr_repeats = nr_repeats.astype("int")
database.update({"MaxSteps":unitvector*MaxSteps})
database.update({"print_steps":unitvector*print_steps})
database.update({"log_steps":unitvector*log_steps})
database.update({"rhovalues":bonds_per_um2})

##################################### ########################
#Other parameters not changed often:
parameters_standard = {}
parameters_standard['MaxSteps'] = None
parameters_standard['print_steps'] = None
parameters_standard['log_steps'] = None
parameters_standard['kT'] = 4.04737e-21				#kBT
parameters_standard['a'] = 0.5*1.36 				#Particle radius [um]
parameters_standard['stress'] = None  				#Shear stress at the channel wall =eta*gammadot
parameters_standard['h']=parameters_standard['a']	#Height of the center of the bead (must be larger than a)
parameters_standard['rho']= None					#1.7e-9*6.023e23*1e-12 	#linkers per um2 on the bottom surface
													#1: slip, roll plus slip: balance horzontal force and torque
parameters_standard['linkerpositionnoise'] = 0.1 	#relative fluctuations in linker positions, |dr|/r with dr variation, and r average distance between linkers
													#fluctuation is only on position on bead!
parameters_standard['attachmentdirection'] = 1 		#0: initial linkers are vertical; 1: normal to bead surface
parameters_standard['extralinkers']=15				#include extra tethers on the right so bead can roll
parameters_standard['slipconditions'] = 1 			#0: no slip, pure rolling: only balance torque, and assume Dx=theta*a
													#1: slip conditions: balance both force and torque

#Set linker mechanical properties
parameters_standard['Lmax'] = 0.056					#contour length of the DNA linker [um]
parameters_standard['lK'] = 0.050					#Kuhn length DNA linker [um]
parameters_standard['polymermodel'] = 2				#1 = ideal chain, 2 = WLC

#Bond properties (for catch bonds!)
parameters_standard['kon0']	= 1e4					#[s-1] bond formation rate kon in absence of force

parameters_standard['koff0_w'] = 0.031622777		#[s-1] off-rate of a catch bond in a weak state
parameters_standard['koff0_s'] = 1.00e-5			#[s-1] off-rate of a catch bond in a strong state
parameters_standard['koff0_hp'] = 3.1623e-7		#[s-1] opening rate of the hairpin (this opening sets the activation of the catch bond in the simulations)

parameters_standard['del_w'] = 0.00133				#[um]  activation length of the catch bond in the weak state
parameters_standard['del_s'] = 0.00182				#[um]  activation length of the catch bond in the strong state
parameters_standard['del_hp'] = 0.020				#[um]  activation length of the hairpin (this hairpin opening sets the activation of the catch bond in the simulations)

parameters_standard['logfile']="logfile.txt"

#generate a list of simulations for the slurm manager to loop over
generate_simulationslist.generate_simulationslist(densities=database["rhovalues"],stresses=database["stresses"],nr_simulations=nr_simulations)

for densitycount,density in enumerate(database["rhovalues"]):
	for stressindex,stressvalue in enumerate(database['stresses']):
		for repeatnr in range(nr_repeats[stressindex]):
			#make the simulation folder
			os.makedirs("../simulation/density_"+str(density)+"/stress_"+str(stressvalue)+"/rep_"+str(repeatnr)+"/")

			#Update the list of standard parameters with the parameters defined at the top.
			parameters_measurement = parameters_standard.copy()
			parameters_measurement.update({"seed":random.randint(0,100000)})
			parameters_measurement.update({"stress":stressvalue})
			parameters_measurement.update({"MaxSteps":MaxSteps})
			parameters_measurement.update({"print_steps":print_steps})
			parameters_measurement.update({"log_steps":log_steps})
			parameters_measurement.update({"rho":bonds_per_um2[densitycount]})

			#Generate the simulation input file using the generate_input.py script
			generate_input.generate_input(parameterlib=parameters_measurement,outputfilename="../simulation/density_"+str(density)+"/stress_"+str(stressvalue)+"/rep_"+str(repeatnr)+"/input.txt")
