from __future__ import division, unicode_literals, print_function
import numpy as np
#This script is called by rollingbead_f.py, and it computes the on-rates kon for all unbound linkers and the off-rates koff for all bound linkers, both in the weak and strong states.
#The interconversion rate constants from weak to strong state are also computed.
#These rate constants are then used by the KMC algorithm to decide which step to take.

def RateConstants(linkers,par,F):

	#Obtain the rate constants: kon/koff depending on whether tether is connected.
	#F is pased for eff

	k = np.zeros((np.shape(linkers.p0)[0],2)) #Make an array of two rows. The first row denotes the koff and kon rates of each linker, the second row denotes the rate constant of switching to the other state.

	#Read all the rate constant parameters
	k0weak = par['koff0_w']
	k0strong = par['koff0_s']
	k0hp = par['koff0_hp']

	#Also read the mechanical susceptibilities dx
	dxweak = par['del_w']
	dxstrong = par['del_s']
	dxhp = par['del_hp']

	#First, compute the offrates for all the linkers:
	k[linkers.state==0,0] = 0													#Because broken bonds can't dissociate further ;)
	k[linkers.state==1,0] = k0weak*np.exp(dxweak*F[linkers.state==1]).T			#weak linkers
	k[linkers.state==2,0] = k0strong*np.exp(dxstrong*F[linkers.state==2]).T		#strong linkers

	#Next, compute the interconversion rates for the weak linkers to become strong and for the strong linkers to become weak
	k[linkers.state==0,1] = 0
	k[linkers.state==1,1] = k0hp*np.exp(dxhp*F[linkers.state==1]).T
	k[linkers.state==2,1] = 0	#We do not allow activated catch bonds to return to inactivated catch bonds, but this could be here included if desired.

	#Finally, we compute the on-rates for all the unbound linkers
	if par['attachmentdirection']==0:	#In case the attachment direction is normal to the surface of the channel
		R=par['h']-np.sqrt(np.square(par['a']) - (np.square(linkers.p0[linkers.state==0,0]) + linkers.p0[linkers.state==0,1])) #Distance to bead surface
	else:								#In case the attachment direction is normal to the microparticle surface (used in all simulations of the manuscript)
		r=np.sqrt(np.square(linkers.p0[linkers.state==0,0]) + np.square(linkers.p0[linkers.state==0,1]))
		r[r==0] = 1e-10 #If r is practically zero, set r to a very low value, to avoid divisions by zero
		alpha=np.arctan(r/par['h'])
		R=np.divide(r,np.sin(alpha))-par['a']

	if par['polymermodel']==1: 						#If the freely-jointed chain behavior is used.
		dG=3*np.square(R)/(par['Lmax']*par['lK'])	#Extensional change in free energy delta G
	else:											#If the worm-like chain model is used.
		x=R/par['Lmax']								#Compute the relative extension every non-formed bond would have if it was formed

		Fi = (2/par['lK'])*(np.divide(0.25,np.square(1-x))-0.25+x-0.8*np.power(x,2.15))	#Compute the extension force using the WLC force extension model
		dG = (2/par['lK'])*(np.divide(0.25*np.square(x),(1-x))+0.5*np.square(x)-(0.8/3.15)*np.power(x,3.15))  #Compute the extension energy delta G

		A=Fi*par['del_w']-dG
		A[A>0]=0
		A[x>1]=-np.inf

	kon = par['kon0']*np.exp(A)						#Compute the on-rate kon for every unbound linker
	kon.shape = (np.shape(kon)[0],1)	

	k[linkers.state==0,0]=kon.T
	#return the array with all rate constants, for both the formation and dissociation of the bonds.
	return(k)
