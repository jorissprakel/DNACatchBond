import random


###########################################################

#NOTE: This script is called by generate_measurementarchitecture.py
#It generates an input file in the simulation folder, which can later be run with the SLURM task manager through initialize_jobarrayparallel.sh

#####################################################################

def generate_input(parameterlib,outputfilename):

	print(outputfilename)
	outputfile = open(outputfilename,'w')
	for elem in parameterlib:
		outputfile.write(elem+" = "+str(parameterlib[elem])+"\n")

	outputfile.close()
