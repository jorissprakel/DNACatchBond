from __future__ import division, unicode_literals, print_function
import numpy as np

#This script is called by Equilibrate.py when the particle is rotated during the gradient descent approach.
#The script recalculates the positions r1 of every bound linker on the particle as the particle rotates.

def RotateBead(r0,par,theta):

	#Rotate the bead over an angle theta (clockwise)

	c = np.cos(theta)
	s = np.sin(theta)

	r = np.copy(r0)

	r[:,0] = r0[:,0]*c - (par['h']-r0[:,2])*s
	r[:,2] = par['h'] - (r0[:,0]*s + (par['h']-r0[:,2])*c)

	return(r)