from __future__ import division, unicode_literals, print_function
import numpy as np
import TotalLinkerForceAndTorque
import matplotlib.pylab as plt
from matplotlib.ticker import AutoMinorLocator,Locator
import matplotlib.ticker
from matplotlib import cm
from matplotlib.colors import rgb2hex
import matplotlib.colors as colors
import pickle as pk
import os

#######################################################################################################

#NOTE: This script plots the average heatmap of the distribution of weak and strong bonds over the course of a rolling adhesion catch bond simulation
#The heat map is averaged over the 20 simulation repeats to yield the figure in fig. 3B of the manuscript.
#note that the TotalLinkerForceAndTorque script has to be present for this script to run.

#######################################################################################################


#Define two color maps for weak and strong catch bonds
Blues = cm.get_cmap('Blues', 255)
Oranges = cm.get_cmap('Oranges', 255)

#Set the heat map settings: dimensions in pixels, size, and colour map range.
maxcolourrange = 100
heatmap_dimensions = (150,23) 				#nr of datapoints in the xy axes
heatmap_size = ((-0.8,0.5),(-0.5,0.5))		#boundaries of the heatmap in um (xmin,xmax),(ymin,ymax) 
cutoff_count = 1							#Only count those bins that have at least cutoff_count registered forces
a =	0.5*1.36								#um, Set particle radius

#Temperature and force conversion to pN
T = 293.15 #K
Force_kTperum_to_pN = 4.0454*10**(-3)		

#update heatmap_size according to particle radius, to find the size in um
heatmap_size = np.multiply(heatmap_size,a)		#boundaries of the heatmap in um (xmin,xmax),(ymin,ymax) 

#Plot both the activated and unactivated linkers
plot_activated = True
plot_unactivated = True

#Redefine the class linker to store the linker information
class linker:
	def __init__(self,p0,p1,state,edge):
		self.p0=p0
		self.p1=p1
		self.state=state
		self.edge=edge

#Move to the simulation folder
datafolder = "../simulation"
dilutions = os.listdir(datafolder)

#Loop over all the bond densities (in this case one. 2000 bonds/um2)
counter = 0
for dindex, dilution in enumerate(dilutions):
	stresses = os.listdir(datafolder+"/"+dilution+"/")

	#loop over the stresses/flowrates
	for stressindex,stress in enumerate(stresses):

		repeats = os.listdir(datafolder+"/"+dilution+"/"+stress)

		#Define 2D numpy arrays for storing the number of bonds in each bin, and the force in each bin for both the weak and strong state of the catch bond.
		counts = np.zeros((heatmap_dimensions[0],heatmap_dimensions[1]))
		forcedata_weak = np.zeros((heatmap_dimensions[0],heatmap_dimensions[1]))
		forcedata_strong = np.zeros((heatmap_dimensions[0],heatmap_dimensions[1]))

		#Define the bin edges
		distancebinedges_x = np.linspace(start=heatmap_size[0][0],stop=heatmap_size[0][1],num=heatmap_dimensions[0]+1)
		distancebinedges_y = np.linspace(start=heatmap_size[1][0],stop=heatmap_size[1][1],num=heatmap_dimensions[1]+1)

		#Loop over each repeat of the measurements (20 repeats in total.)
		for repindex,repeat in enumerate(repeats):
			datapath=datafolder+"/"+dilution+"/"+stress+"/"+repeat+"/"
			analysisfolder = "../analysis/"+dilution+"/"+stress+"/heatmap_forcedistribution/"

			if not os.path.exists(analysisfolder):
				os.makedirs(analysisfolder)

			#Read in the simulation parameters from the input file used for the simulations
			par={}
			inputfile = open(datapath+"input.txt",'r')
			for line in inputfile:
				name,value = line.split(" = ")
				if name in ['attachmentdirection','extralinkers','slipconditions','polymermodel','MaxSteps','print_steps','log_steps','seed']:
					value = int(value)
				elif name in ['trajectoryfile','parametersfile','logfile']:
					value = str(value)[:-1]
				else:
					value = float(value)
				par[name]=value

			#read in the log file containing the particle position and the pickle files containing the linker positions and forces over time
			picklefiles = os.listdir(datapath+"/linkers_traj/")
			logfile = np.loadtxt(datapath+"/log.csv",delimiter=',',skiprows=1)
			steps=logfile[:,0]
			beadpositions = logfile[:,3]

			#loop over all the pickle files containing the linker positions and forces.
			for pkindex,pickle in enumerate(picklefiles):

				totalnr = len(picklefiles)*len(repeats)*len(stresses)*len(dilutions)	
				percentage = (counter/totalnr)*100
				counter+=1

				linkerpath = picklefiles[pkindex]
				stepvalue = int(linkerpath[:-7])

				with open(datapath+"/linkers_traj/"+linkerpath, 'rb') as pickle_file:
					linkerframe=pk.load(pickle_file)
				with open(datapath+"/edge_traj/"+linkerpath, 'rb') as pickle_file:
					edgeframe=pk.load(pickle_file)

				#Load in the linker information
				linkers = linker(p0=linkerframe[:,0:2],p1=linkerframe[:,2:5],state=linkerframe[:,5],edge=edgeframe[:])

				#Separate the linkers in weak, strong and not connected linkers
				p0s_strong = linkers.p0[linkers.state==2]			
				p0s_weak = linkers.p0[linkers.state==1]			
				p0s_notconnected = linkers.p0[linkers.state==0]

				linkers_weak =linkerframe[linkerframe[:,5]==1]
				linkers_strong =linkerframe[linkerframe[:,5]==2]
				
				#Compute the forces on all the linkers
				F,T,x,Fx=TotalLinkerForceAndTorque.TotalLinkerForceAndTorque(linkers,par)

				#convert force to pN for weak and strong linkers
				F = np.multiply(F,Force_kTperum_to_pN)
				Forces_weak = F[linkers.state==1]
				Forces_strong = F[linkers.state==2]

				if plot_activated: #For the catch bonds in the strong state
					#For each bond, determine its bin within the heatmap, and add the force to the value in this bin:
					for bondindex, p0 in enumerate(p0s_strong):
						#If bond fits within the current bin: add its force to the force in the bin.
						if p0s_strong[bondindex,0]>heatmap_size[0][0] and p0s_strong[bondindex,0]<heatmap_size[0][1] and p0s_strong[bondindex,1]>heatmap_size[1][0] and p0s_strong[bondindex,1]<heatmap_size[1][1]:
							xbin = np.where(distancebinedges_x>p0s_strong[bondindex,0])[0][0]-1
							ybin = np.where(distancebinedges_y>p0s_strong[bondindex,1])[0][0]-1

							#Keep track of the number of bonds in each bin and the summed force in each bin
							counts[xbin,ybin]+=1
							forcedata_strong[xbin,ybin]=forcedata_strong[xbin,ybin]+Forces_strong[bondindex]
				
				if plot_unactivated: #Again, for the catch bonds in the strong state
					#For each bond, determine its bin within the heatmap, and add the force to the value in this bin:
					for bondindex, p0 in enumerate(p0s_weak):
						#If bond fits within the current bin: add its force to the force in the bin.
						if p0s_weak[bondindex,0]>heatmap_size[0][0] and p0s_weak[bondindex,0]<heatmap_size[0][1] and p0s_weak[bondindex,1]>heatmap_size[1][0] and p0s_weak[bondindex,1]<heatmap_size[1][1]:
							xbin = np.where(distancebinedges_x>p0s_weak[bondindex,0])[0][0]-1
							ybin = np.where(distancebinedges_y>p0s_weak[bondindex,1])[0][0]-1

							#Keep track of the number of bonds in each bin and the summed force in each bin
							counts[xbin,ybin]+=1
							forcedata_weak[xbin,ybin]=forcedata_weak[xbin,ybin]+Forces_weak[bondindex]

		#Set the force data of binds with less than 1 count to 0
		forcedata_weak[counts<cutoff_count]=0
		#Normalize the force data in each bin by dividing the total force by the number of bonds in this bin.
		forcedata_weak_normalized=np.divide(forcedata_weak,counts).T
		forcedata_weak_normalized_plot = np.log(forcedata_weak_normalized)

		#Repeat the same step for the strong state
		forcedata_strong[counts<cutoff_count]=0
		forcedata_strong_normalized=np.divide(forcedata_strong,counts).T
		forcedata_strong_normalized_plot = np.log(forcedata_strong_normalized)

		#Initiate a matplotlib figure
		fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(3.2, 3.0)) #figsize=(3.6, 3.2) figsize=(5, 5)
		plt.subplots_adjust(left=0.29, wspace=0.38, hspace=0.38, top=0.90, bottom=0.2, right=0.93)
		ax.tick_params(axis='y',**{'which':'major','width':2.2,'length':6,'direction':'in','left':True,'right':True})
		ax.tick_params(axis='y',**{'which':'minor','width':1.5,'length':3,'direction':'in','left':True,'right':True})  
		ax.tick_params(axis='x',**{'which':'major','width':1.9,'length':6.5,'direction':'in','bottom':True,'top':True})    
		ax.tick_params(axis='x',**{'which':'minor','width':1.3,'length':3.5,'direction':'in','bottom':True,'top':True})
		[line.set_linewidth(1.2) for line in ax.spines.values()]

		if np.sum(np.isfinite(forcedata_weak_normalized))>0:		#if there are unactivated (weak state) catch bonds throughtout the simulation
			#Plot the heat map of the weak state catch bonds
			plot=ax.imshow(forcedata_weak_normalized,aspect="auto",norm=colors.LogNorm(vmin=1e-4,vmax=forcedata_weak_normalized[np.isfinite(forcedata_weak_normalized)].max()),cmap=Blues,extent=(heatmap_size[0][0],heatmap_size[0][1],heatmap_size[1][0],heatmap_size[1][1]))
		
		if np.sum(np.isfinite(forcedata_strong_normalized))>0:		#if there are activated (strong state) catch bonds throughtout the simulation
			#Plot the heat map of the strong state catch bonds
			plot=ax.imshow(forcedata_strong_normalized,aspect="auto",norm=colors.LogNorm(vmin=1e-4,vmax=forcedata_strong_normalized[np.isfinite(forcedata_strong_normalized)].max()),cmap=Oranges,extent=(heatmap_size[0][0],heatmap_size[0][1],heatmap_size[1][0],heatmap_size[1][1]))
		
		#Define the limits of the plot.
		ax.set_xlim(left = -0.5*par['a'],right=0.35*par['a'])
		ax.set_ylim(bottom = -0.4*par['a'], top = 0.4*par['a'])

		for tick in ax.xaxis.get_major_ticks():
			tick.label.set_fontsize(14)
		for tick in ax.yaxis.get_major_ticks():
			tick.label.set_fontsize(14)

		ax.xaxis.set_minor_locator(AutoMinorLocator(2))
		ax.yaxis.set_minor_locator(AutoMinorLocator(2))

		plt.rcParams['font.size'] = '12'
		ax.set_xlabel(r'$x$',fontsize=19)
		ax.set_ylabel(r'$y$',fontsize = 19,rotation="vertical")

		#store the heatmap as a high res png
		plt.savefig("heatmap_weak_strong.png",dpi=600)
		plt.show()
		plt.close()

